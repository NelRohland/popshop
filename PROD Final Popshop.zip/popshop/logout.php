<?php
/**
 * Logout Script
 * Destroys user session
 */

require_once 'includes/config.php';
require_once 'includes/functions.php';

// Clear session
session_destroy();

// Redirect to login
header("Location: " . APP_URL . "/login.php");
exit;

?>
