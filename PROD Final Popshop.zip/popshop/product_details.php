<?php
$page_title = 'Product Details';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database connection
$db = new Database();
$mysqli = $db->getConnection();

// Redirect to login if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Get product ID
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id <= 0) {
    header('Location: ' . APP_URL . '/browse_products.php');
    exit;
}

// Get product details
$query = "SELECT p.*, u.username as seller_name, u.user_id as seller_id
          FROM products p
          JOIN users u ON p.seller_id = u.user_id
          WHERE p.product_id = ? AND p.status = 'active'";

$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    $_SESSION['error_message'] = 'Product not found or has been removed.';
    header('Location: ' . APP_URL . '/browse_products.php');
    exit;
}

// Get product images
$img_query = "SELECT image_path FROM product_images WHERE product_id = ? ORDER BY display_order";
$img_stmt = $mysqli->prepare($img_query);
$img_stmt->bind_param('i', $product_id);
$img_stmt->execute();
$img_result = $img_stmt->get_result();
$product_images = $img_result->fetch_all(MYSQLI_ASSOC);

// Add main image if it exists
if (!empty($product['main_image'])) {
    array_unshift($product_images, ['image_path' => $product['main_image']]);
}

// Remove duplicates
$seen = [];
$unique_images = [];
foreach ($product_images as $img) {
    if (!isset($seen[$img['image_path']])) {
        $seen[$img['image_path']] = true;
        $unique_images[] = $img;
    }
}
$product_images = $unique_images;
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12">
        <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-outline-secondary btn-sm mb-3">
            Back to Marketplace
        </a>
    </div>
</div>

<div class="row">
    <!-- Product Images -->
    <div class="col-lg-6">
        <div class="product-details-hero">
            <div class="product-images-carousel">
                <?php if (!empty($product_images)): ?>
                    <img id="mainImage" src="<?php echo APP_URL; ?>/<?php echo htmlspecialchars($product_images[0]['image_path']); ?>" 
                         alt="<?php echo htmlspecialchars($product['product_name']); ?>" 
                         class="product-image-main"
                         onerror="this.src='<?php echo APP_URL; ?>/assets/placeholder.png'">
                    
                    <?php if (count($product_images) > 1): ?>
                    <div class="product-image-thumbnails">
                        <?php foreach ($product_images as $index => $img): ?>
                        <img src="<?php echo APP_URL; ?>/<?php echo htmlspecialchars($img['image_path']); ?>" 
                             alt="Product image <?php echo $index + 1; ?>" 
                             class="product-image-thumbnail <?php echo $index === 0 ? 'active' : ''; ?>"
                             onclick="changeMainImage(this.src)"
                             onerror="this.src='<?php echo APP_URL; ?>/assets/placeholder.png'">
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="product-image-main" style="background-color: #f0f0f0; display: flex; align-items: center; justify-content: center; min-height: 400px;">
                        <span style="color: #999; font-size: 1.2rem;">No Images Available</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Product Information -->
    <div class="col-lg-6">
        <!-- Product Header -->
        <div class="product-info-section">
            <span class="info-label">Category</span>
            <p class="mb-3"><?php echo htmlspecialchars($product['category']); ?></p>

            <h1><?php echo htmlspecialchars($product['product_name']); ?></h1>

            <div class="mb-3">
                <span class="badge bg-primary" style="background-color: var(--primary-color) !important;">
                    <?php echo ucfirst($product['condition']); ?> Condition
                </span>
            </div>

            <p class="text-muted mb-3" style="font-size: 0.9rem;">
                Listed on <?php echo date('M d, Y', strtotime($product['created_at'])); ?>
            </p>
        </div>

        <!-- Price -->
        <div class="product-info-section" style="background: linear-gradient(135deg, rgba(255, 51, 51, 0.05) 0%, rgba(255, 51, 51, 0.02) 100%);">
            <span class="info-label">Price</span>
            <h2 style="color: var(--primary-color); font-weight: 700; margin-bottom: 1rem;">
                <?php echo formatCurrency($product['price']); ?>
            </h2>

            <?php if ($product['quantity_available'] > 0): ?>
            <div class="mb-3">
                <span class="info-label">Availability</span>
                <p class="mb-0">
                    <span class="badge bg-success">In Stock</span>
                    <?php echo $product['quantity_available']; ?> available
                </p>
            </div>
            <?php else: ?>
            <div class="mb-3">
                <span class="badge bg-secondary">Out of Stock</span>
            </div>
            <?php endif; ?>

            <?php if ($product['quantity_available'] > 0 && $_SESSION['user_id'] != $product['seller_id']): ?>
            <form method="POST" action="<?php echo APP_URL; ?>/checkout.php" class="mb-2">
                <input type="hidden" name="add_to_cart" value="1">
                <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                <div class="d-flex gap-2 mb-2">
                    <input type="number" name="quantity" value="1" min="1"
                           max="<?php echo $product['quantity_available']; ?>"
                           class="form-control" style="width:80px;">
                    <button type="submit" class="btn btn-primary btn-lg flex-grow-1">Add to Cart</button>
                </div>
            </form>
            <a href="<?php echo APP_URL; ?>/checkout.php" class="btn btn-outline-primary w-100">View Cart &amp; Checkout</a>
            <?php elseif ($_SESSION['user_id'] == $product['seller_id']): ?>
            <div class="alert alert-info mb-0">
                This is your product. <a href="<?php echo APP_URL; ?>/user_listings.php">View your listings</a>
            </div>
            <?php else: ?>
            <button class="btn btn-secondary w-100" disabled>Out of Stock</button>
            <?php endif; ?>
        </div>

        <!-- Description -->
        <div class="product-info-section">
            <span class="info-label">Description</span>
            <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
        </div>

        <!-- Messages (product-scoped) -->
        <div class="product-info-section">
            <span class="info-label">Messages with Seller</span>
            <?php
            // load product-scoped messages between current user and seller
            if (isLoggedIn()):
                $current = getUserId();
                $seller = $product['seller_id'];
                $mstmt = $mysqli->prepare("SELECT m.*, u.username as sender_name FROM messages m JOIN users u ON m.sender_id = u.user_id WHERE m.product_id = ? AND ((m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)) ORDER BY m.sent_at ASC");
                $mstmt->bind_param('iiiii', $product_id, $current, $seller, $seller, $current);
                $mstmt->execute();
                $mres = $mstmt->get_result();
                $threads = $mres->fetch_all(MYSQLI_ASSOC);
            ?>

            <?php if (!empty($threads)): ?>
                <div class="mb-3 messages-thread" style="max-height:300px; overflow:auto; background:#fff; padding:12px; border-radius:6px;">
                    <?php foreach ($threads as $tm): ?>
                        <div style="margin-bottom:8px;">
                            <strong><?php echo htmlspecialchars($tm['sender_name']); ?></strong>
                            <small class="text-muted"> — <?php echo htmlspecialchars($tm['sent_at']); ?></small>
                            <div><?php echo nl2br(htmlspecialchars($tm['message_content'])); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted">No messages yet for this product.</p>
            <?php endif; ?>

            <?php if (isLoggedIn() && $_SESSION['user_id'] != $product['seller_id']): ?>
                <form method="POST" action="<?php echo APP_URL; ?>/send_message.php" class="mt-2">
                    <input type="hidden" name="receiver_id" value="<?php echo $product['seller_id']; ?>">
                    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                    <div class="mb-2">
                        <input name="subject" class="form-control" placeholder="Subject (optional)">
                    </div>
                    <div class="mb-2">
                        <textarea name="message_content" class="form-control" rows="3" placeholder="Write a message to the seller about this product..." required></textarea>
                    </div>
                    <button class="btn btn-sm btn-primary" type="submit">Send Message</button>
                </form>
            <?php endif; ?>

            <?php endif; ?>
        </div>

        <!-- Reviews -->
        <div class="product-info-section">
            <span class="info-label">Reviews</span>
            <?php require_once 'includes/reviews.php';
            $reviews = getApprovedReviews($product['product_id']); ?>

            <?php if (!empty($reviews)): ?>
                <?php foreach ($reviews as $rev): ?>
                    <div class="mb-3">
                        <strong><?php echo htmlspecialchars($rev['username']); ?></strong>
                        <small class="text-muted"> — <?php echo htmlspecialchars($rev['created_at']); ?></small>
                        <p><?php echo nl2br(htmlspecialchars($rev['content'])); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-muted">No reviews yet.</p>
            <?php endif; ?>

            <?php if (isLoggedIn() && $_SESSION['user_id'] != $product['seller_id']): ?>
                <form method="POST" action="<?php echo APP_URL; ?>/submit_review.php">
                    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                    <div class="mb-2">
                        <textarea name="content" class="form-control" rows="3" placeholder="Write a review (will be moderated)" required minlength="10"></textarea>
                    </div>
                    <button class="btn btn-sm btn-primary" type="submit">Submit Review</button>
                </form>
            <?php endif; ?>
        </div>

        <!-- Seller Information -->
        <div class="product-info-section">
            <span class="info-label">Seller</span>
            <div class="seller-card">
                <h5 class="seller-name mb-2">
                    <?php echo htmlspecialchars($product['seller_name']); ?>
                </h5>
                <p class="seller-rating mb-2">
                    <?php
                    require_once 'includes/ratings.php';
                    $avg = getSellerAverageRating($product['seller_id']);
                    $avgDisplay = $avg && $avg['avg_rating'] ? round($avg['avg_rating'],1) : 'N/A';
                    $total = $avg['total'] ?? 0;
                    ?>
                    <span style="color: #FFB800;"><?php echo $avg && $avg['avg_rating'] ? str_repeat('★', round($avg['avg_rating'])) : '☆☆☆☆☆'; ?></span>
                    <strong><?php echo $avgDisplay; ?></strong> (<?php echo $total; ?>)
                </p>
                <p class="text-muted mb-0" style="font-size: 0.9rem;">
                    Active seller with numerous positive reviews
                </p>
            </div>
            <button class="btn btn-outline-primary w-100 mt-2" data-bs-toggle="modal" data-bs-target="#messageModal">Contact Seller</button>
            <?php if ($_SESSION['user_id'] != $product['seller_id']): ?>
            <button class="btn btn-outline-danger btn-sm w-100 mt-2" data-bs-toggle="modal" data-bs-target="#reportModal">
                Report Seller
            </button>
            <?php endif; ?>
            
            <!-- Rating Modal -->
            <?php if (isLoggedIn() && $_SESSION['user_id'] != $product['seller_id']): ?>
            <div class="mt-2">
                <button class="btn btn-outline-success w-100" data-bs-toggle="modal" data-bs-target="#rateModal">Rate Seller</button>
            </div>
            <?php endif; ?>
        </div>

        <!-- Product Details -->
        <div class="product-info-section">
            <span class="info-label">Product Details</span>
            <table class="table table-sm table-borderless">
                <tr>
                    <td style="font-weight: 600; color: var(--text-muted);">Product ID</td>
                    <td style="text-align: right;"><?php echo $product['product_id']; ?></td>
                </tr>
                <tr>
                    <td style="font-weight: 600; color: var(--text-muted);">Condition</td>
                    <td style="text-align: right;"><?php echo ucfirst($product['condition']); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: 600; color: var(--text-muted);">Quantity Available</td>
                    <td style="text-align: right;"><?php echo $product['quantity_available']; ?></td>
                </tr>
                <tr>
                    <td style="font-weight: 600; color: var(--text-muted);">Listed Date</td>
                    <td style="text-align: right;"><?php echo date('M d, Y', strtotime($product['created_at'])); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>

<!-- Related Products Section -->
<div class="row mt-5">
    <div class="col-12">
        <h3 class="section-title">Related Products in <?php echo htmlspecialchars($product['category']); ?></h3>
    </div>
</div>

<div class="row">
    <?php 
    // Get related products
    $related_query = "SELECT p.*, u.username as seller_name
                      FROM products p
                      JOIN users u ON p.seller_id = u.user_id
                      WHERE p.category = ? AND p.product_id != ? AND p.status = 'active'
                      ORDER BY p.created_at DESC
                      LIMIT 4";
    
    $related_stmt = $mysqli->prepare($related_query);
    $related_stmt->bind_param('si', $product['category'], $product_id);
    $related_stmt->execute();
    $related_result = $related_stmt->get_result();
    $related_products = $related_result->fetch_all(MYSQLI_ASSOC);
    
    if (!empty($related_products)):
        foreach ($related_products as $related):
    ?>
    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
        <a href="product_details.php?id=<?php echo $related['product_id']; ?>" class="product-card">
            <div class="product-card-image">
                <?php if (!empty($related['main_image'])): ?>
                    <img src="<?php echo APP_URL; ?>/<?php echo htmlspecialchars($related['main_image']); ?>" 
                         alt="<?php echo htmlspecialchars($related['product_name']); ?>" 
                         class="product-image"
                         onerror="this.src='<?php echo APP_URL; ?>/assets/placeholder.png'">
                <?php else: ?>
                    <div class="product-image" style="background-color: #f0f0f0; display: flex; align-items: center; justify-content: center;">
                        <span style="color: #999;">No Image</span>
                    </div>
                <?php endif; ?>
            </div>
            <div class="product-card-body">
                <h5 class="product-title text-truncate-2">
                    <?php echo htmlspecialchars($related['product_name']); ?>
                </h5>
                <div class="mt-auto">
                    <p class="product-price mb-2"><?php echo formatCurrency($related['price']); ?></p>
                    <small class="text-muted d-block">
                        <?php echo htmlspecialchars($related['seller_name']); ?>
                    </small>
                </div>
            </div>
        </a>
    </div>
    <?php 
        endforeach;
    else:
    ?>
    <div class="col-12">
        <p class="text-muted text-center">No related products found.</p>
    </div>
    <?php endif; ?>
</div>

<script>
function changeMainImage(src) {
    document.getElementById('mainImage').src = src;
    
    // Update active thumbnail
    document.querySelectorAll('.product-image-thumbnail').forEach(img => {
        img.classList.remove('active');
    });
    event.target.classList.add('active');
}
</script>

<?php if (isLoggedIn() && $_SESSION['user_id'] != $product['seller_id']): ?>
<?php $csrf_token = generateCSRFToken(); ?>
<div class="modal fade" id="reportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Report Seller</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo APP_URL; ?>/includes/fraud_report_logic.php">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <input type="hidden" name="reported_user_id" value="<?php echo $product['seller_id']; ?>">
                    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                    <input type="hidden" name="redirect_to" value="<?php echo APP_URL; ?>/product_details.php?id=<?php echo $product['product_id']; ?>">

                    <div class="mb-3">
                        <label class="form-label">Report Type *</label>
                        <select name="report_type" class="form-select" required>
                            <option value="">Select a reason</option>
                            <option value="fraud">Fraud</option>
                            <option value="fake_product">Fake Product</option>
                            <option value="abusive_behavior">Abusive Behavior</option>
                            <option value="inappropriate_content">Inappropriate Content</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description *</label>
                        <textarea name="description" class="form-control" rows="4" required
                                  placeholder="Describe the issue in detail..." minlength="10"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Submit Report</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Message Modal -->
<div class="modal fade" id="messageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Contact <?php echo htmlspecialchars($product['seller_name']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo APP_URL; ?>/send_message.php">
                <div class="modal-body">
                    <input type="hidden" name="receiver_id" value="<?php echo $product['seller_id']; ?>">
                    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                    <div class="mb-2">
                        <label class="form-label">Subject</label>
                        <input name="subject" class="form-control" placeholder="Message subject">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Message</label>
                        <textarea name="message_content" class="form-control" rows="5" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Rate Modal -->
<div class="modal fade" id="rateModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Rate Seller</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="<?php echo APP_URL; ?>/rate_seller.php">
                <div class="modal-body text-center">
                    <input type="hidden" name="seller_id" value="<?php echo $product['seller_id']; ?>">
                    <div class="rating-stars mb-3">
                        <?php for ($i = 5; $i >= 1; $i--): ?>
                            <input type="radio" id="star<?php echo $i; ?>" name="rating" value="<?php echo $i; ?>">
                            <label for="star<?php echo $i; ?>"><?php echo $i; ?>★</label>
                        <?php endfor; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Submit Rating</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

