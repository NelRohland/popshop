<?php
$page_title = 'My Orders';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect(APP_URL . '/login.php');
}

$db = new Database();
$mysqli = $db->getConnection();
$user_id = getUserId();

$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

$where = "o.buyer_id = $user_id";
if (!empty($status_filter)) {
    $where .= " AND o.status = '" . $mysqli->real_escape_string($status_filter) . "'";
}

$total = $mysqli->query("SELECT COUNT(*) as t FROM orders o WHERE $where")->fetch_assoc()['t'];
$total_pages = max(1, (int)ceil($total / $per_page));

$orders_result = $mysqli->query("
    SELECT o.*, u.username as seller_name, u.full_name as seller_full_name,
           COUNT(oi.order_item_id) as item_count
    FROM orders o
    JOIN users u ON o.seller_id = u.user_id
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    WHERE $where
    GROUP BY o.order_id
    ORDER BY o.order_date DESC
    LIMIT $offset, $per_page
");
$orders = $orders_result->fetch_all(MYSQLI_ASSOC);

$statuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled', 'refunded'];
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="section-title">My Orders</h1>
    </div>
</div>

<!-- Filters -->
<div class="row mb-4">
    <div class="col-12">
        <div class="filter-card">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Filter by Status</label>
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="">All Orders</option>
                        <?php foreach ($statuses as $s): ?>
                        <option value="<?php echo $s; ?>" <?php echo $status_filter === $s ? 'selected' : ''; ?>>
                            <?php echo ucfirst($s); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo APP_URL; ?>/my_orders.php" class="btn btn-outline-secondary w-100">Clear</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (!empty($orders)): ?>
<div class="dashboard-card">
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Seller</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                    <td>
                        <?php echo htmlspecialchars($order['seller_full_name']); ?><br>
                        <small class="text-muted">@<?php echo htmlspecialchars($order['seller_name']); ?></small>
                    </td>
                    <td><?php echo $order['item_count']; ?> item<?php echo $order['item_count'] != 1 ? 's' : ''; ?></td>
                    <td><strong><?php echo formatCurrency($order['total_amount']); ?></strong></td>
                    <td>
                        <span class="badge" style="background-color:<?php
                            $colors = ['pending'=>'#f39c12','paid'=>'#27ae60','shipped'=>'#3498db','delivered'=>'#27ae60','cancelled'=>'#e74c3c','refunded'=>'#95a5a6'];
                            echo $colors[$order['status']] ?? '#7f8c8d';
                        ?>;">
                            <?php echo ucfirst($order['status']); ?>
                        </span>
                    </td>
                    <td><small><?php echo date('M d, Y', strtotime($order['order_date'])); ?></small></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                                data-bs-target="#orderDetail<?php echo $order['order_id']; ?>">
                            View
                        </button>
                    </td>
                </tr>

                <!-- Order Detail Modal -->
                <div class="modal fade" id="orderDetail<?php echo $order['order_id']; ?>" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Order #<?php echo $order['order_id']; ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <h6>Seller</h6>
                                        <p><?php echo htmlspecialchars($order['seller_full_name']); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Delivery Address</h6>
                                        <p>
                                            <?php echo htmlspecialchars($order['delivery_address']); ?>,
                                            <?php echo htmlspecialchars($order['delivery_city']); ?>,
                                            <?php echo htmlspecialchars($order['delivery_province']); ?>
                                            <?php echo htmlspecialchars($order['delivery_postal_code']); ?>
                                        </p>
                                    </div>
                                </div>
                                <h6>Items</h6>
                                <?php
                                $items = $mysqli->query("
                                    SELECT oi.*, p.product_name FROM order_items oi
                                    JOIN products p ON oi.product_id = p.product_id
                                    WHERE oi.order_id = {$order['order_id']}
                                ")->fetch_all(MYSQLI_ASSOC);
                                ?>
                                <table class="table table-sm">
                                    <thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
                                    <tbody>
                                        <?php foreach ($items as $item): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td><?php echo formatCurrency($item['unit_price']); ?></td>
                                            <td><?php echo formatCurrency($item['subtotal']); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <div class="text-end">
                                    <strong>Order Total: <?php echo formatCurrency($order['total_amount']); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($total_pages > 1): ?>
    <nav class="mt-3">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($status_filter) ? '&status=' . urlencode($status_filter) : ''; ?>">
                    <?php echo $i; ?>
                </a>
            </li>
            <?php endfor; ?>
        </ul>
    </nav>
    <?php endif; ?>
</div>
<?php else: ?>
<div class="no-results">
    <div class="no-results-icon">📦</div>
    <h4>No Orders Found</h4>
    <p class="no-results-text">
        <?php echo !empty($status_filter) ? 'No ' . $status_filter . ' orders.' : "You haven't placed any orders yet."; ?>
    </p>
    <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-primary mt-3">Start Shopping</a>
</div>
<?php endif; ?>

<style>
.filter-card { background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
.dashboard-card { background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
</style>

<?php require_once 'includes/footer.php'; ?>
