<?php
$page_title = 'Add Product';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database
$db = new Database();
$conn = $db->getConnection();

// Redirect if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Redirect if not seller
if (!hasRole('seller') && !hasRole('admin')) {
    $_SESSION['error_message'] = 'You must be a seller to add products';
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = sanitize($_POST['product_name'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $category = sanitize($_POST['category'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    $condition = sanitize($_POST['condition'] ?? 'new');
    
    // Validate inputs
    if (empty($product_name) || empty($description) || empty($category) || $price <= 0 || $quantity < 0) {
        $error_message = 'Please fill in all required fields with valid values.';
    } else {
        // Insert product
        $product_name_escaped = $conn->real_escape_string($product_name);
        $description_escaped = $conn->real_escape_string($description);
        $category_escaped = $conn->real_escape_string($category);
        
        $insert_query = "
        INSERT INTO products (seller_id, product_name, description, category, price, quantity_available, `condition`, status)
        VALUES ($user_id, '$product_name_escaped', '$description_escaped', '$category_escaped', $price, $quantity, '$condition', 'pending_approval')
        ";
        
        if ($conn->query($insert_query)) {
            $product_id = $conn->insert_id;
            
            // Handle image uploads
            if (!empty($_FILES['images']['name'][0])) {
                $upload_dir = 'uploads/products/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                $image_count = 0;
                foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                    if (!empty($tmp_name)) {
                        $file_name = basename($_FILES['images']['name'][$key]);
                        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
                        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
                        
                        if (in_array(strtolower($file_ext), $allowed_ext)) {
                            $new_filename = 'product_' . $product_id . '_' . time() . '_' . rand(1000, 9999) . '.' . $file_ext;
                            $upload_path = $upload_dir . $new_filename;
                            
                            if (move_uploaded_file($tmp_name, $upload_path)) {
                                $image_count++;
                                $display_order = $image_count;
                                
                                // Set first image as main image
                                if ($image_count === 1) {
                                    $update_main = "UPDATE products SET main_image = '$upload_path' WHERE product_id = $product_id";
                                    $conn->query($update_main);
                                }
                                
                                // Insert image record
                                $img_query = "INSERT INTO product_images (product_id, image_path, display_order) VALUES ($product_id, '$upload_path', $display_order)";
                                $conn->query($img_query);
                            }
                        }
                    }
                }
            }
            
            $_SESSION['success_message'] = 'Product added successfully! It is pending approval.';
            header('Location: ' . APP_URL . '/seller_dashboard.php');
            exit;
        } else {
            $error_message = 'Error adding product. Please try again.';
        }
    }
}

// Get categories
$categories_query = "SELECT category_id, category_name FROM categories ORDER BY category_name";
$categories = $conn->query($categories_query)->fetch_all(MYSQLI_ASSOC);
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="section-title">Add New Product</h1>
    </div>
</div>

<?php if (!empty($error_message)): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo htmlspecialchars($error_message); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <div class="dashboard-card">
            <form method="POST" enctype="multipart/form-data" class="needs-validation">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Product Name *</label>
                        <input type="text" class="form-control" name="product_name" required 
                               placeholder="Enter product name" maxlength="255">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Category *</label>
                        <select class="form-select" name="category" required>
                            <option value="">Select a category</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo htmlspecialchars($cat['category_name']); ?>">
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                           <label class="form-label">Price (ZAR) *</label>
                        <input type="number" class="form-control" name="price" required 
                               placeholder="0.00" min="0.01" step="0.01">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Quantity *</label>
                        <input type="number" class="form-control" name="quantity" required 
                               placeholder="0" min="0" value="1">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Condition *</label>
                        <select class="form-select" name="condition" required>
                            <option value="new">New</option>
                            <option value="like_new">Like New</option>
                            <option value="good">Good</option>
                            <option value="fair">Fair</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Description *</label>
                    <textarea class="form-control" name="description" required rows="5"
                              placeholder="Describe your product in detail..." maxlength="2000"></textarea>
                    <small class="form-text text-muted">Maximum 2000 characters</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Product Images</label>
                    <input type="file" class="form-control" name="images[]" multiple accept="image/*" 
                           id="imageInput">
                    <small class="form-text text-muted">Upload up to 5 images (JPG, PNG, GIF). First image will be main image.</small>
                    
                    <div id="imagePreview" class="mt-3" style="display: none;">
                        <div class="row g-2" id="previewContainer"></div>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg">Add Product</button>
                    <a href="<?php echo APP_URL; ?>/seller_dashboard.php" class="btn btn-secondary btn-lg">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="dashboard-card">
            <h5 class="mb-3">Quick Tips</h5>
            <ul class="list-unstyled">
                <li class="mb-2">
                    <strong>📸 Images:</strong> Clear, well-lit photos increase sales
                </li>
                <li class="mb-2">
                    <strong>💰 Pricing:</strong> Check similar products for competitive pricing
                </li>
                <li class="mb-2">
                    <strong>📝 Description:</strong> Be detailed and honest about condition
                </li>
                <li class="mb-2">
                    <strong>⚙️ Category:</strong> Choose the most accurate category
                </li>
                <li class="mb-2">
                    <strong>✅ Approval:</strong> Products are reviewed before going live
                </li>
            </ul>
        </div>
    </div>
</div>

<style>
.dashboard-card {
    background: white;
    border-radius: 8px;
    padding: 2rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.form-label {
    font-weight: 600;
    color: var(--dark-text);
    margin-bottom: 0.5rem;
}

.form-control, .form-select {
    border: 1px solid var(--border-light);
    border-radius: 6px;
    padding: 0.75rem;
}

.form-control:focus, .form-select:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 0.2rem rgba(255, 51, 51, 0.15);
}

.btn-primary {
    background-color: var(--primary-color);
    border-color: var(--primary-color);
}

.btn-primary:hover {
    background-color: var(--primary-dark);
    border-color: var(--primary-dark);
}

.preview-image {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 6px;
    border: 2px solid var(--border-light);
}

.preview-wrapper {
    position: relative;
}

.preview-remove {
    position: absolute;
    top: 5px;
    right: 5px;
    background: rgba(255, 51, 51, 0.9);
    color: white;
    border: none;
    border-radius: 50%;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}
</style>

<script>
document.getElementById('imageInput').addEventListener('change', function(e) {
    const files = Array.from(this.files);
    const previewContainer = document.getElementById('previewContainer');
    const previewDiv = document.getElementById('imagePreview');
    
    previewContainer.innerHTML = '';
    
    if (files.length > 5) {
        alert('Maximum 5 images allowed');
        this.value = '';
        previewDiv.style.display = 'none';
        return;
    }
    
    if (files.length > 0) {
        previewDiv.style.display = 'block';
        
        files.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const col = document.createElement('div');
                col.className = 'col-4';
                col.innerHTML = `
                    <div class="preview-wrapper">
                        <img src="${e.target.result}" class="preview-image" alt="Preview">
                        <small class="d-block mt-1">${file.name}</small>
                    </div>
                `;
                previewContainer.appendChild(col);
            };
            reader.readAsDataURL(file);
        });
    } else {
        previewDiv.style.display = 'none';
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
