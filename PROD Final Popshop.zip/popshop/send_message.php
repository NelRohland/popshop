<?php
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) redirect('login.php');

$sender_id = getUserId();
$receiver_id = intval($_POST['receiver_id'] ?? 0);
$product_id = intval($_POST['product_id'] ?? 0);
$subject = sanitize($_POST['subject'] ?? '');
$message = sanitize($_POST['message_content'] ?? '');

if (!$receiver_id || !$message) {
    $_SESSION['error_message'] = 'Please provide a recipient and message.';
    redirect($_SERVER['HTTP_REFERER'] ?? 'index.php');
}

$db = new Database();
$mysqli = $db->getConnection();

$stmt = $mysqli->prepare("INSERT INTO messages (sender_id, receiver_id, product_id, subject, message_content) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param('iiiss', $sender_id, $receiver_id, $product_id, $subject, $message);

if ($stmt->execute()) {
    $_SESSION['success_message'] = 'Message sent.';
} else {
    $_SESSION['error_message'] = 'Failed to send message.';
}

redirect($_SERVER['HTTP_REFERER'] ?? ('product_details.php?id=' . $product_id));
