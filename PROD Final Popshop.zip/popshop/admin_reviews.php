<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (!isAdmin()) redirect('login.php');

$db = new Database();
$mysqli = $db->getConnection();

// Fetch unapproved reviews
$stmt = $mysqli->prepare("SELECT pr.*, p.product_name, u.username FROM product_reviews pr JOIN products p ON pr.product_id = p.product_id JOIN users u ON pr.buyer_id = u.user_id WHERE pr.approved = 0 ORDER BY pr.created_at DESC");
$stmt->execute();
$res = $stmt->get_result();
$reviews = $res->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['review_id'] ?? 0);
    if ($action && $id) {
        if ($action === 'approve') {
            $u = $mysqli->prepare("UPDATE product_reviews SET approved = 1 WHERE review_id = ?");
            $u->bind_param('i', $id);
            $u->execute();
        } elseif ($action === 'delete') {
            $u = $mysqli->prepare("DELETE FROM product_reviews WHERE review_id = ?");
            $u->bind_param('i', $id);
            $u->execute();
        }
        redirect('admin_reviews.php');
    }
}

require_once 'includes/header.php';
?>
<h2>Product Reviews Moderation</h2>
<?php if (empty($reviews)): ?>
  <p>No pending reviews.</p>
<?php else: ?>
  <table class="table">
    <thead><tr><th>Product</th><th>Reviewer</th><th>Content</th><th>Date</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($reviews as $r): ?>
      <tr>
        <td><?php echo htmlspecialchars($r['product_name']); ?></td>
        <td><?php echo htmlspecialchars($r['username']); ?></td>
        <td><?php echo nl2br(htmlspecialchars($r['content'])); ?></td>
        <td><?php echo htmlspecialchars($r['created_at']); ?></td>
        <td>
          <form method="POST" style="display:inline">
            <input type="hidden" name="review_id" value="<?php echo $r['review_id']; ?>">
            <button name="action" value="approve" class="btn btn-sm btn-success">Approve</button>
          </form>
          <form method="POST" style="display:inline">
            <input type="hidden" name="review_id" value="<?php echo $r['review_id']; ?>">
            <button name="action" value="delete" class="btn btn-sm btn-danger">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
