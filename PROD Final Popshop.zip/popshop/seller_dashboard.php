<?php
$page_title = 'Seller Dashboard';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database
$db = new Database();
$mysqli = $db->getConnection();

// Redirect to login if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Check if user is a seller or admin
if (!hasRole('seller') && !hasRole('admin')) {
    $_SESSION['error_message'] = 'You do not have access to the seller dashboard.';
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get seller's statistics
$stats_query = "
SELECT 
    (SELECT COUNT(*) FROM products WHERE seller_id = $user_id) as total_products,
    (SELECT COUNT(*) FROM products WHERE seller_id = $user_id AND status = 'active') as active_products,
    (SELECT SUM(quantity_available) FROM products WHERE seller_id = $user_id) as total_inventory,
    (SELECT COUNT(*) FROM orders WHERE seller_id = $user_id) as total_orders,
    (SELECT COUNT(*) FROM orders WHERE seller_id = $user_id AND status IN ('shipped', 'delivered')) as completed_orders,
    (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE seller_id = $user_id AND status IN ('paid', 'shipped', 'delivered')) as total_revenue
";

$stats = $mysqli->query($stats_query)->fetch_assoc();

// Get recent orders
$recent_orders_query = "
SELECT o.*, 
       u.username as buyer_name,
       COUNT(oi.order_item_id) as item_count
FROM orders o
JOIN users u ON o.buyer_id = u.user_id
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.seller_id = $user_id
GROUP BY o.order_id
ORDER BY o.order_date DESC
LIMIT 5
";
$recent_orders = $mysqli->query($recent_orders_query)->fetch_all(MYSQLI_ASSOC);

// Get low stock products
$low_stock_query = "
SELECT product_id, product_name, quantity_available, price
FROM products
WHERE seller_id = $user_id 
  AND quantity_available < 5 
  AND status = 'active'
ORDER BY quantity_available ASC
LIMIT 5
";
$low_stock = $mysqli->query($low_stock_query)->fetch_all(MYSQLI_ASSOC);

// Get monthly revenue
$revenue_query = "
SELECT 
    DATE_FORMAT(order_date, '%Y-%m') as month,
    SUM(total_amount) as revenue,
    COUNT(*) as orders
FROM orders
WHERE seller_id = $user_id AND status IN ('paid', 'shipped', 'delivered')
GROUP BY DATE_FORMAT(order_date, '%Y-%m')
ORDER BY month DESC
LIMIT 6
";
$monthly_revenue = $mysqli->query($revenue_query)->fetch_all(MYSQLI_ASSOC);

// Get seller average rating
require_once 'includes/ratings.php';
$rating_info = getSellerAverageRating($user_id);
$seller_avg = $rating_info['avg_rating'] ?? null;
$seller_total_ratings = $rating_info['total'] ?? 0;
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="section-title">Seller Dashboard</h1>
    </div>
</div>

<div class="row mb-3">
    <div class="col-md-4">
        <div class="dashboard-card">
            <h6 class="card-title">Seller Rating</h6>
            <p style="font-size:1.25rem; margin:0;">
                <?php if ($seller_avg): ?>
                    <span style="color:#FFB800; font-weight:700;"><?php echo round($seller_avg,1); ?></span>
                    <span class="text-muted">(<?php echo $seller_total_ratings; ?> ratings)</span>
                <?php else: ?>
                    <span class="text-muted">No ratings yet</span>
                <?php endif; ?>
            </p>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: var(--primary-color);">
                <span>📦</span>
            </div>
            <div class="stat-content">
                <p class="stat-label">Active Products</p>
                <h3 class="stat-value"><?php echo $stats['active_products']; ?></h3>
                <small class="stat-subtext">of <?php echo $stats['total_products']; ?> total</small>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #27ae60;">
                <span>📊</span>
            </div>
            <div class="stat-content">
                <p class="stat-label">Total Inventory</p>
                <h3 class="stat-value"><?php echo $stats['total_inventory'] ?? 0; ?></h3>
                <small class="stat-subtext">units in stock</small>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #f39c12;">
                <span>📦</span>
            </div>
            <div class="stat-content">
                <p class="stat-label">Total Orders</p>
                <h3 class="stat-value"><?php echo $stats['total_orders']; ?></h3>
                <small class="stat-subtext"><?php echo $stats['completed_orders']; ?> completed</small>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #e74c3c;">
                <span>💰</span>
            </div>
            <div class="stat-content">
                <p class="stat-label">Total Revenue</p>
                <h3 class="stat-value"><?php echo formatCurrency($stats['total_revenue']); ?></h3>
                <small class="stat-subtext">from completed orders</small>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Quick Actions -->
    <div class="col-lg-3 mb-4">
        <div class="dashboard-card">
            <h5 class="card-title">Quick Actions</h5>
            <div class="quick-actions">
                <a href="<?php echo APP_URL; ?>/add_product.php" class="quick-action-btn">
                    <span class="action-icon">➕</span>
                    <span class="action-text">Add New Product</span>
                </a>
                <a href="<?php echo APP_URL; ?>/user_listings.php" class="quick-action-btn">
                    <span class="action-icon">📋</span>
                    <span class="action-text">Manage Products</span>
                </a>
                <a href="<?php echo APP_URL; ?>/seller_orders.php" class="quick-action-btn">
                    <span class="action-icon">📦</span>
                    <span class="action-text">View Orders</span>
                </a>
                <a href="<?php echo APP_URL; ?>/seller_inventory.php" class="quick-action-btn">
                    <span class="action-icon">📊</span>
                    <span class="action-text">Inventory</span>
                </a>
                <a href="<?php echo APP_URL; ?>/seller_analytics.php" class="quick-action-btn">
                    <span class="action-icon">📈</span>
                    <span class="action-text">Analytics</span>
                </a>
            </div>
        </div>

        <!-- Low Stock Alert -->
        <?php if (!empty($low_stock)): ?>
        <div class="dashboard-card alert-card mt-3">
            <h5 class="card-title">Low Stock Alert</h5>
            <div class="alert-list">
                <?php foreach ($low_stock as $product): ?>
                <div class="alert-item">
                    <span class="alert-product">
                        <?php echo htmlspecialchars(substr($product['product_name'], 0, 20)); ?>
                    </span>
                    <span class="alert-qty" style="color: #e74c3c; font-weight: 600;">
                        <?php echo $product['quantity_available']; ?> left
                    </span>
                </div>
                <?php endforeach; ?>
                <a href="<?php echo APP_URL; ?>/seller_inventory.php" class="btn btn-sm btn-outline-primary w-100 mt-2">
                    Manage Inventory
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Recent Orders -->
    <div class="col-lg-6 mb-4">
        <div class="dashboard-card">
            <h5 class="card-title">Recent Orders</h5>
            <?php if (!empty($recent_orders)): ?>
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Buyer</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_orders as $order): ?>
                        <tr>
                            <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                            <td><?php echo htmlspecialchars($order['buyer_name']); ?></td>
                            <td><?php echo $order['item_count']; ?></td>
                            <td><strong><?php echo formatCurrency($order['total_amount']); ?></strong></td>
                            <td>
                                <span class="badge" style="background-color: <?php 
                                    $status_color = [
                                        'pending' => '#f39c12',
                                        'paid' => '#27ae60',
                                        'shipped' => '#3498db',
                                        'delivered' => '#27ae60',
                                        'cancelled' => '#e74c3c',
                                        'refunded' => '#95a5a6'
                                    ];
                                    echo $status_color[$order['status']] ?? '#7f8c8d';
                                ?>;">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td><small><?php echo date('M d', strtotime($order['order_date'])); ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <a href="<?php echo APP_URL; ?>/seller_orders.php" class="btn btn-sm btn-primary">View All Orders</a>
            <?php else: ?>
            <p class="text-muted">No orders yet</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Revenue Chart -->
    <div class="col-lg-3 mb-4">
        <div class="dashboard-card">
            <h5 class="card-title">Monthly Revenue</h5>
            <?php if (!empty($monthly_revenue)): ?>
            <div class="revenue-list">
                <?php foreach ($monthly_revenue as $month): ?>
                <div class="revenue-item">
                    <span class="revenue-month"><?php echo date('M Y', strtotime($month['month'] . '-01')); ?></span>
                    <div class="revenue-bar-container">
                        <div class="revenue-bar" style="width: <?php 
                            $max_revenue = max(array_column($monthly_revenue, 'revenue'));
                            echo ($month['revenue'] / $max_revenue) * 100; 
                        ?>%; background-color: var(--primary-color);"></div>
                    </div>
                    <span class="revenue-amount"><?php echo formatCurrency($month['revenue']); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="text-muted">No revenue data yet</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.stat-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s, box-shadow 0.3s;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
}

.stat-content {
    flex: 1;
}

.stat-label {
    margin: 0;
    color: var(--text-muted);
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 600;
}

.stat-value {
    margin: 0.5rem 0 0 0;
    color: var(--dark-text);
    font-weight: 700;
    font-size: 1.75rem;
}

.stat-subtext {
    color: var(--text-muted);
}

.dashboard-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.dashboard-card.alert-card {
    border-left: 4px solid #e74c3c;
    background-color: rgba(231, 76, 60, 0.03);
}

.card-title {
    margin: 0 0 1rem 0;
    color: var(--dark-text);
    font-weight: 600;
}

.quick-actions {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.quick-action-btn {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
    background-color: var(--light-bg);
    color: var(--dark-text);
    text-decoration: none;
    border-radius: 6px;
    transition: all 0.3s;
    font-weight: 500;
}

.quick-action-btn:hover {
    background-color: var(--primary-color);
    color: white;
    text-decoration: none;
}

.action-icon {
    font-size: 1.2rem;
}

.action-text {
    flex: 1;
}

.alert-list {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.alert-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem;
    background-color: white;
    border-left: 3px solid #e74c3c;
    border-radius: 4px;
}

.alert-product {
    font-weight: 500;
    color: var(--dark-text);
}

.alert-qty {
    font-size: 0.9rem;
}

.revenue-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.revenue-item {
    display: grid;
    grid-template-columns: 60px 1fr 60px;
    gap: 0.75rem;
    align-items: center;
}

.revenue-month {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--dark-text);
}

.revenue-bar-container {
    background-color: var(--border-light);
    height: 8px;
    border-radius: 4px;
    overflow: hidden;
}

.revenue-bar {
    height: 100%;
    border-radius: 4px;
    transition: width 0.3s;
}

.revenue-amount {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--primary-color);
    text-align: right;
}

@media (max-width: 768px) {
    .stat-card {
        flex-direction: column;
        text-align: center;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>
