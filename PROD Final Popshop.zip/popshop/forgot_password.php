<?php
$page_title = 'Forgot Password';
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/db_connect.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect(APP_URL . '/index.php');
}

$showResetForm = false;
$email = '';

// Check if we have a verified email in session
if (isset($_SESSION['reset_email'])) {
    $showResetForm = true;
    $email = $_SESSION['reset_email'];
}
?>
<?php require_once 'includes/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card shadow-sm">
            <div class="card-body p-5">
                
                <?php if (!$showResetForm): ?>
                    <!-- Email Lookup Form -->
                    <h2 class="card-title text-center mb-4">Forgot Password</h2>

                    <?php require_once 'includes/error_msg.php'; ?>

                    <p class="text-muted text-center mb-4">
                        Enter your email address to reset your password.
                    </p>

                    <form method="POST" action="includes/forgot_password_logic.php" novalidate>
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="step" value="verify_email">

                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" required 
                                   value="<?php echo isset($_POST['email']) ? sanitize($_POST['email']) : ''; ?>">
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mb-3">Continue</button>
                    </form>

                <?php else: ?>
                    <!-- Password Reset Form -->
                    <h2 class="card-title text-center mb-4">Reset Password</h2>

                    <?php require_once 'includes/error_msg.php'; ?>

                    <p class="text-muted text-center mb-4">
                        Enter your new password for <strong><?php echo sanitize($email); ?></strong>
                    </p>

                    <form method="POST" action="includes/forgot_password_logic.php" novalidate>
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="step" value="reset_password">
                        <input type="hidden" name="email" value="<?php echo sanitize($email); ?>">

                        <div class="mb-3">
                            <label for="password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <small class="form-text text-muted">Min 8 chars, must include uppercase, lowercase, and digits</small>
                        </div>

                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mb-3">Reset Password</button>
                        <button type="button" class="btn btn-secondary w-100" onclick="window.location.href='<?php echo APP_URL; ?>/forgot_password.php'">Back</button>
                    </form>

                <?php endif; ?>

                <hr>
                <p class="text-center">
                    <a href="login.php">Back to Login</a>
                </p>
                <p class="text-center">
                    Don't have an account? <a href="register.php">Register here</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
