<?php
session_start();
require_once 'includes/ratings.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) redirect('login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $buyerId = getUserId();
    $sellerId = intval($_POST['seller_id'] ?? 0);
    $rating = intval($_POST['rating'] ?? 0);

    if ($sellerId && $rating >=1 && $rating <=5) {
        submitSellerRating($sellerId, $buyerId, $rating);
        $_SESSION['flash_success'] = 'Rating submitted.';
    } else {
        $_SESSION['flash_error'] = 'Invalid rating.';
    }
}

redirect($_SERVER['HTTP_REFERER'] ?? 'index.php');
