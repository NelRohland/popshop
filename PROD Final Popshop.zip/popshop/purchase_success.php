<?php
$page_title = 'Order Confirmed';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect(APP_URL . '/login.php');
}

$db = new Database();
$mysqli = $db->getConnection();
$user_id = getUserId();

$order_ids_raw = isset($_GET['orders']) ? $_GET['orders'] : '';
$order_ids = array_filter(array_map('intval', explode(',', $order_ids_raw)));

$orders = [];
foreach ($order_ids as $oid) {
    $stmt = $mysqli->prepare("
        SELECT o.*, u.username as seller_name, u.full_name as seller_full_name
        FROM orders o
        JOIN users u ON o.seller_id = u.user_id
        WHERE o.order_id = ? AND o.buyer_id = ?
    ");
    $stmt->bind_param('ii', $oid, $user_id);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    if ($order) {
        $items_stmt = $mysqli->prepare("
            SELECT oi.*, p.product_name, p.main_image
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = ?
        ");
        $items_stmt->bind_param('i', $oid);
        $items_stmt->execute();
        $order['items'] = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $orders[] = $order;
    }
}
?>
<?php require_once 'includes/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-lg-8">

        <?php if (empty($orders)): ?>
        <div class="no-results">
            <h4>Order not found</h4>
            <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-primary mt-3">Browse Products</a>
        </div>
        <?php else: ?>

        <!-- Success Banner -->
        <div class="success-banner mb-4">
            <div class="success-icon">&#10003;</div>
            <div>
                <h2 class="success-title">Order Placed Successfully!</h2>
                <p class="success-sub">Thank you for your purchase. The seller will be in touch to arrange delivery.</p>
            </div>
        </div>

        <!-- Order Cards -->
        <?php foreach ($orders as $order): ?>
        <div class="order-card mb-4">
            <div class="order-card-header">
                <div>
                    <span class="order-id">Order #<?php echo $order['order_id']; ?></span>
                    <span class="badge bg-warning text-dark ms-2"><?php echo ucfirst($order['status']); ?></span>
                </div>
                <small class="text-muted"><?php echo date('M d, Y', strtotime($order['order_date'])); ?></small>
            </div>

            <div class="order-card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6 class="info-section-label">Seller</h6>
                        <p class="mb-0"><?php echo htmlspecialchars($order['seller_full_name']); ?> (@<?php echo htmlspecialchars($order['seller_name']); ?>)</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="info-section-label">Payment Method</h6>
                        <p class="mb-0"><?php echo htmlspecialchars($order['payment_method']); ?></p>
                    </div>
                </div>

                <div class="mb-3">
                    <h6 class="info-section-label">Delivery Address</h6>
                    <p class="mb-0">
                        <?php echo htmlspecialchars($order['delivery_address']); ?>,
                        <?php echo htmlspecialchars($order['delivery_city']); ?>,
                        <?php echo htmlspecialchars($order['delivery_province']); ?>
                        <?php echo htmlspecialchars($order['delivery_postal_code']); ?>
                    </p>
                </div>

                <h6 class="info-section-label">Items</h6>
                <?php foreach ($order['items'] as $item): ?>
                <div class="order-item">
                    <div class="order-item-img">
                        <?php if (!empty($item['main_image'])): ?>
                        <img src="<?php echo APP_URL; ?>/<?php echo htmlspecialchars($item['main_image']); ?>"
                             alt="<?php echo htmlspecialchars($item['product_name']); ?>"
                             onerror="this.src='<?php echo APP_URL; ?>/assets/placeholder.png'">
                        <?php else: ?>
                        <div class="order-no-image">No Image</div>
                        <?php endif; ?>
                    </div>
                    <div class="order-item-details">
                        <p class="order-item-name"><?php echo htmlspecialchars($item['product_name']); ?></p>
                        <p class="order-item-meta">Qty: <?php echo $item['quantity']; ?> &times; <?php echo formatCurrency($item['unit_price']); ?></p>
                    </div>
                    <div class="order-item-subtotal">
                        <?php echo formatCurrency($item['subtotal']); ?>
                    </div>
                </div>
                <?php endforeach; ?>

                <div class="order-total-row">
                    <span>Order Total</span>
                    <span class="order-total-amount"><?php echo formatCurrency($order['total_amount']); ?></span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <div class="d-flex gap-3 flex-wrap">
            <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-primary">Continue Shopping</a>
            <?php if (hasRole('buyer') || hasRole('seller') || hasRole('admin')): ?>
            <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-outline-secondary">Back to Marketplace</a>
            <?php endif; ?>
        </div>

        <?php endif; ?>
    </div>
</div>

<style>
.success-banner {
    background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
    border-radius: 12px;
    padding: 2rem;
    display: flex;
    align-items: center;
    gap: 1.5rem;
    color: white;
}

.success-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: rgba(255,255,255,0.25);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.75rem;
    font-weight: 700;
    flex-shrink: 0;
}

.success-title {
    margin: 0 0 0.5rem 0;
    font-weight: 700;
    font-size: 1.5rem;
}

.success-sub {
    margin: 0;
    opacity: 0.9;
}

.order-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    overflow: hidden;
}

.order-card-header {
    background: var(--light-bg);
    padding: 1rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--border-light);
}

.order-id {
    font-weight: 700;
    font-size: 1rem;
    color: var(--dark-text);
}

.order-card-body {
    padding: 1.5rem;
}

.info-section-label {
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--text-muted);
    font-weight: 700;
    margin-bottom: 0.4rem;
}

.order-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 0.75rem 0;
    border-bottom: 1px solid var(--border-light);
}

.order-item:last-of-type {
    border-bottom: none;
}

.order-item-img {
    width: 60px;
    height: 60px;
    border-radius: 6px;
    overflow: hidden;
    flex-shrink: 0;
    background: var(--light-bg);
}

.order-item-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.order-no-image {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.7rem;
    color: var(--text-muted);
}

.order-item-details {
    flex: 1;
}

.order-item-name {
    font-weight: 600;
    margin: 0;
    color: var(--dark-text);
}

.order-item-meta {
    margin: 0.2rem 0 0 0;
    font-size: 0.85rem;
    color: var(--text-muted);
}

.order-item-subtotal {
    font-weight: 700;
    color: var(--primary-color);
}

.order-total-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 2px solid var(--border-light);
    font-weight: 700;
    font-size: 1.05rem;
}

.order-total-amount {
    color: var(--primary-color);
    font-size: 1.2rem;
}
</style>

<?php require_once 'includes/footer.php'; ?>
