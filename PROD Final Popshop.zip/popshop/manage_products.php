<?php
$page_title = 'Manage Products';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database
$db = new Database();
$mysqli = $db->getConnection();

// Redirect if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Check if user is a seller or admin
if (!hasRole('seller') && !hasRole('admin')) {
    $_SESSION['error_message'] = 'You do not have access to this page.';
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product_id'])) {
    $product_id = (int)$_POST['delete_product_id'];
    
    // Verify product belongs to seller
    $verify_query = "SELECT product_id FROM products WHERE product_id = $product_id AND seller_id = $user_id";
    $verify = $mysqli->query($verify_query)->fetch_assoc();
    
    if ($verify) {
        // Delete images first
        $delete_images = "DELETE FROM product_images WHERE product_id = $product_id";
        $mysqli->query($delete_images);
        
        // Delete product
        $delete_product = "DELETE FROM products WHERE product_id = $product_id";
        if ($mysqli->query($delete_product)) {
            $_SESSION['success_message'] = 'Product deleted successfully!';
        }
    }
    header('Location: ' . APP_URL . '/manage_products.php');
    exit;
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id']) && isset($_POST['status'])) {
    $product_id = (int)$_POST['product_id'];
    $status = sanitize($_POST['status']);
    
    $valid_statuses = ['active', 'inactive', 'sold', 'pending_approval'];
    if (!in_array($status, $valid_statuses)) {
        $status = 'pending_approval';
    }
    
    // Verify product belongs to seller
    $verify_query = "SELECT product_id FROM products WHERE product_id = $product_id AND seller_id = $user_id";
    $verify = $mysqli->query($verify_query)->fetch_assoc();
    
    if ($verify) {
        $update_query = "UPDATE products SET status = '$status' WHERE product_id = $product_id";
        if ($mysqli->query($update_query)) {
            $_SESSION['success_message'] = 'Product status updated!';
        }
    }
    header('Location: ' . APP_URL . '/manage_products.php');
    exit;
}

// Get filter and search parameters
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Build query
$product_where = "p.seller_id = $user_id";
$count_where = "seller_id = $user_id";

if (!empty($status_filter)) {
    $product_where .= " AND p.status = '$status_filter'";
    $count_where .= " AND status = '$status_filter'";
}

if (!empty($search)) {
    $search_escaped = $mysqli->real_escape_string($search);
    $product_where .= " AND p.product_name LIKE '%$search_escaped%'";
    $count_where .= " AND product_name LIKE '%$search_escaped%'";
}

// Get total products
$count_query = "SELECT COUNT(*) as total FROM products WHERE $count_where";
$total_products = $mysqli->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_products / $per_page);

// Get products
$products_query = "
SELECT p.*,
       (SELECT COUNT(*) FROM product_images WHERE product_id = p.product_id) as image_count,
       (SELECT COUNT(*) FROM order_items oi
        JOIN orders o ON oi.order_id = o.order_id
        WHERE oi.product_id = p.product_id AND o.status IN ('paid', 'shipped', 'delivered')) as sales_count
FROM products p
WHERE $product_where
ORDER BY p.created_at DESC
LIMIT $offset, $per_page
";
$products = $mysqli->query($products_query)->fetch_all(MYSQLI_ASSOC);
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1 class="section-title">Manage My Products</h1>
    </div>
    <div class="col-md-4">
        <a href="<?php echo APP_URL; ?>/add_product.php" class="btn btn-primary w-100">
            <strong>+ Add New Product</strong>
        </a>
    </div>
</div>

<?php if (!empty($search) || !empty($status_filter)): ?>
<div class="alert alert-info alert-dismissible fade show">
    <strong>Filters Applied</strong> - 
    <?php if (!empty($search)): ?>Search: <?php echo htmlspecialchars($search); ?> <?php endif; ?>
    <?php if (!empty($status_filter)): ?>Status: <?php echo ucfirst($status_filter); ?> <?php endif; ?>
    <a href="<?php echo APP_URL; ?>/manage_products.php" class="alert-link">Clear filters</a>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Filters -->
<div class="row mb-4">
    <div class="col-12">
        <div class="filter-card">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <input type="text" name="search" class="form-control" placeholder="Search products..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        <option value="pending_approval" <?php echo $status_filter === 'pending_approval' ? 'selected' : ''; ?>>Pending Approval</option>
                        <option value="sold" <?php echo $status_filter === 'sold' ? 'selected' : ''; ?>>Sold</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (!empty($products)): ?>
<div class="row">
    <?php foreach ($products as $product): ?>
    <div class="col-md-6 col-lg-4 mb-4">
        <div class="product-card">
            <div class="product-image" style="height: 200px; overflow: hidden; border-radius: 8px;">
                <?php if (!empty($product['main_image'])): ?>
                    <img src="<?php echo APP_URL; ?>/<?php echo htmlspecialchars($product['main_image']); ?>" 
                         alt="<?php echo htmlspecialchars($product['product_name']); ?>" 
                         style="width: 100%; height: 100%; object-fit: cover;">
                <?php else: ?>
                    <div style="width: 100%; height: 100%; background: var(--light-bg); display: flex; align-items: center; justify-content: center;">
                        <span style="color: var(--text-muted);">No Image</span>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="p-3">
                <h5 class="card-title" style="margin-bottom: 0.5rem;">
                    <?php echo htmlspecialchars(substr($product['product_name'], 0, 40)); ?>
                </h5>
                
                <div class="mb-2">
                    <span class="badge <?php 
                        $status_colors = [
                            'active' => 'bg-success',
                            'inactive' => 'bg-secondary',
                            'pending_approval' => 'bg-warning',
                            'sold' => 'bg-dark'
                        ];
                        echo $status_colors[$product['status']] ?? 'bg-secondary';
                    ?>">
                        <?php echo ucfirst(str_replace('_', ' ', $product['status'])); ?>
                    </span>
                </div>
                
                <div class="mb-2" style="font-size: 0.9rem; color: var(--text-muted);">
                    <div><strong>Price:</strong> <?php echo formatCurrency($product['price']); ?></div>
                    <div><strong>Stock:</strong> <?php echo $product['quantity_available']; ?> units</div>
                    <div><strong>Sales:</strong> <?php echo $product['sales_count']; ?> sold</div>
                </div>
                
                <hr>
                
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-sm btn-outline-primary flex-grow-1" 
                            data-bs-toggle="modal" data-bs-target="#editModal<?php echo $product['product_id']; ?>">
                        Edit
                    </button>
                    <form method="POST" style="display: inline;" 
                          onsubmit="return confirm('Are you sure you want to delete this product?');">
                        <input type="hidden" name="delete_product_id" value="<?php echo $product['product_id']; ?>">
                        <button type="submit" class="btn btn-sm btn-outline-danger flex-grow-1">
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Edit Modal -->
        <div class="modal fade" id="editModal<?php echo $product['product_id']; ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Update Product Status</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                            
                            <div class="mb-3">
                                <label class="form-label">Product Name</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($product['product_name']); ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select">
                                    <option value="active" <?php echo $product['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo $product['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    <option value="sold" <?php echo $product['status'] === 'sold' ? 'selected' : ''; ?>>Sold</option>
                                </select>
                                <small class="form-text text-muted">pending_approval status cannot be changed by sellers</small>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Status</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Pagination -->
<?php if ($total_pages > 1): ?>
<div class="row mt-5">
    <div class="col-12">
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?><?php echo !empty($status_filter) ? '&status=' . urlencode($status_filter) : ''; ?>">Previous</a>
                </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?><?php echo !empty($status_filter) ? '&status=' . urlencode($status_filter) : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?><?php echo !empty($status_filter) ? '&status=' . urlencode($status_filter) : ''; ?>">Next</a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div>
<?php endif; ?>

<?php else: ?>
<div class="alert alert-info">
    <strong>No products found.</strong>
    <?php if (!empty($search) || !empty($status_filter)): ?>
    Try adjusting your filters or <a href="<?php echo APP_URL; ?>/manage_products.php" class="alert-link">view all products</a>
    <?php else: ?>
    <a href="<?php echo APP_URL; ?>/add_product.php" class="alert-link">Add your first product</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<style>
.product-card {
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s, box-shadow 0.3s;
}

.product-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.filter-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}
</style>

<?php require_once 'includes/footer.php'; ?>
