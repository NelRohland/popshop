<?php
$page_title = 'Admin Dashboard';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

$db = new Database();
$conn = $db->getConnection();

if (!isLoggedIn()) {
    redirect(APP_URL . '/login.php');
}

if (!isAdmin()) {
    $_SESSION['error_message'] = 'You do not have permission to access the admin panel';
    redirect(APP_URL . '/index.php');
}

$current_user_id = getUserId();
$role_options = ['buyer', 'seller', 'admin'];
$user_status_options = ['active', 'inactive', 'suspended', 'banned'];
$product_status_options = ['pending_approval', 'active', 'inactive', 'sold'];
$report_status_options = ['pending', 'investigating', 'resolved', 'dismissed'];

// Handle admin actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_user_role') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $new_role = sanitize($_POST['new_role'] ?? '');

        if ($user_id === $current_user_id) {
            $_SESSION['error_message'] = 'You cannot change your own role.';
        } elseif (!in_array($new_role, $role_options, true)) {
            $_SESSION['error_message'] = 'Invalid role selected.';
        } else {
            $user_check = $conn->query("SELECT user_type FROM users WHERE user_id = $user_id")->fetch_assoc();
            if ($user_check) {
                $old_role = $user_check['user_type'];
                $update_sql = "UPDATE users SET user_type = '$new_role' WHERE user_id = $user_id";
                if ($conn->query($update_sql)) {
                    $_SESSION['success_message'] = 'User role updated successfully.';
                }
            }
        }

        header('Location: ' . APP_URL . '/admin_page.php');
        exit;
    }

    if ($action === 'update_user_status') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $new_status = sanitize($_POST['new_status'] ?? '');

        if ($user_id === $current_user_id) {
            $_SESSION['error_message'] = 'You cannot change your own status.';
        } elseif (!in_array($new_status, $user_status_options, true)) {
            $_SESSION['error_message'] = 'Invalid status selected.';
        } else {
            $user_check = $conn->query("SELECT status FROM users WHERE user_id = $user_id")->fetch_assoc();
            if ($user_check) {
                $update_sql = "UPDATE users SET status = '$new_status' WHERE user_id = $user_id";
                if ($conn->query($update_sql)) {
                    $_SESSION['success_message'] = 'User status updated successfully.';
                }
            }
        }

        header('Location: ' . APP_URL . '/admin_page.php');
        exit;
    }

    if ($action === 'update_product_status') {
        $product_id = (int)($_POST['product_id'] ?? 0);
        $new_status = sanitize($_POST['new_status'] ?? '');

        if (!in_array($new_status, $product_status_options, true)) {
            $_SESSION['error_message'] = 'Invalid product status selected.';
        } else {
            $product_check = $conn->query("SELECT product_id FROM products WHERE product_id = $product_id")->fetch_assoc();
            if ($product_check) {
                $update_sql = "UPDATE products SET status = '$new_status' WHERE product_id = $product_id";
                if ($conn->query($update_sql)) {
                    $_SESSION['success_message'] = 'Product status updated successfully.';
                }
            }
        }

        header('Location: ' . APP_URL . '/admin_page.php');
        exit;
    }

    if ($action === 'update_report_status') {
        $report_id = (int)($_POST['report_id'] ?? 0);
        $new_status = sanitize($_POST['new_status'] ?? '');
        $admin_notes = sanitize($_POST['admin_notes'] ?? '');

        if (!in_array($new_status, $report_status_options, true)) {
            $_SESSION['error_message'] = 'Invalid report status selected.';
        } else {
            $report_check = $conn->query("SELECT report_id FROM fraud_reports WHERE report_id = $report_id")->fetch_assoc();
            if ($report_check) {
                $resolved_at = $new_status === 'resolved' ? ", resolved_at = NOW()" : "";
                $update_sql = "UPDATE fraud_reports SET status = '$new_status', admin_notes = '$admin_notes' $resolved_at WHERE report_id = $report_id";
                if ($conn->query($update_sql)) {
                    $_SESSION['success_message'] = 'Fraud report updated successfully.';
                }
            }
        }

        header('Location: ' . APP_URL . '/admin_page.php');
        exit;
    }
}

// Filters and pagination
$user_search = isset($_GET['user_search']) ? sanitize($_GET['user_search']) : '';
$user_role_filter = isset($_GET['user_role']) ? sanitize($_GET['user_role']) : '';
$user_status_filter = isset($_GET['user_status']) ? sanitize($_GET['user_status']) : '';
$product_search = isset($_GET['product_search']) ? sanitize($_GET['product_search']) : '';
$product_status_filter = isset($_GET['product_status']) ? sanitize($_GET['product_status']) : '';
$report_status_filter = isset($_GET['report_status']) ? sanitize($_GET['report_status']) : '';

$user_page = isset($_GET['user_page']) ? max(1, (int)$_GET['user_page']) : 1;
$product_page = isset($_GET['product_page']) ? max(1, (int)$_GET['product_page']) : 1;
$user_per_page = 10;
$product_per_page = 10;
$user_offset = ($user_page - 1) * $user_per_page;
$product_offset = ($product_page - 1) * $product_per_page;

$role_counts = $conn->query("SELECT user_type, COUNT(*) as total FROM users GROUP BY user_type")->fetch_all(MYSQLI_ASSOC);
$stats_query = "
SELECT
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM users WHERE status = 'active') as active_users,
    (SELECT COUNT(*) FROM products WHERE status = 'pending_approval') as pending_products,
    (SELECT COUNT(*) FROM fraud_reports WHERE status IN ('pending', 'investigating')) as open_reports,
    (SELECT COUNT(*) FROM products) as total_products,
    (SELECT COUNT(*) FROM orders) as total_orders
";
$stats = $conn->query($stats_query)->fetch_assoc();

$user_where = '1=1';
if ($user_search !== '') {
    $user_search_escaped = $conn->real_escape_string($user_search);
    $user_where .= " AND (username LIKE '%$user_search_escaped%' OR email LIKE '%$user_search_escaped%' OR full_name LIKE '%$user_search_escaped%')";
}
if ($user_role_filter !== '' && in_array($user_role_filter, $role_options, true)) {
    $user_where .= " AND user_type = '$user_role_filter'";
}
if ($user_status_filter !== '' && in_array($user_status_filter, $user_status_options, true)) {
    $user_where .= " AND status = '$user_status_filter'";
}

$user_total = $conn->query("SELECT COUNT(*) as total FROM users WHERE $user_where")->fetch_assoc()['total'];
$user_total_pages = max(1, (int)ceil($user_total / $user_per_page));

$users_query = "
SELECT user_id, username, email, full_name, phone_number, user_type, status, created_at
FROM users
WHERE $user_where
ORDER BY created_at DESC
LIMIT $user_offset, $user_per_page
";
$users = $conn->query($users_query)->fetch_all(MYSQLI_ASSOC);

$product_where = '1=1';
if ($product_search !== '') {
    $product_search_escaped = $conn->real_escape_string($product_search);
    $product_where .= " AND (p.product_name LIKE '%$product_search_escaped%' OR p.category LIKE '%$product_search_escaped%' OR u.username LIKE '%$product_search_escaped%')";
}
if ($product_status_filter !== '' && in_array($product_status_filter, $product_status_options, true)) {
    $product_where .= " AND p.status = '$product_status_filter'";
}

$product_total = $conn->query("SELECT COUNT(*) as total FROM products p JOIN users u ON p.seller_id = u.user_id WHERE $product_where")->fetch_assoc()['total'];
$product_total_pages = max(1, (int)ceil($product_total / $product_per_page));

$products_query = "
SELECT p.product_id, p.product_name, p.category, p.price, p.quantity_available, p.status, p.created_at,
       u.username as seller_username, u.full_name as seller_name
FROM products p
JOIN users u ON p.seller_id = u.user_id
WHERE $product_where
ORDER BY CASE WHEN p.status = 'pending_approval' THEN 0 ELSE 1 END, p.created_at DESC
LIMIT $product_offset, $product_per_page
";
$products = $conn->query($products_query)->fetch_all(MYSQLI_ASSOC);

$report_where = '1=1';
if ($report_status_filter !== '' && in_array($report_status_filter, $report_status_options, true)) {
    $report_where .= " AND fr.status = '$report_status_filter'";
}

$reports_query = "
SELECT fr.report_id, fr.report_type, fr.description, fr.status, fr.admin_notes, fr.created_at,
       reporter.username as reporter_username,
       reported.username as reported_username,
       p.product_name,
       o.order_id
FROM fraud_reports fr
JOIN users reporter ON fr.reporter_id = reporter.user_id
JOIN users reported ON fr.reported_user_id = reported.user_id
LEFT JOIN products p ON fr.product_id = p.product_id
LEFT JOIN orders o ON fr.order_id = o.order_id
WHERE $report_where
ORDER BY fr.created_at DESC
LIMIT 10
";
$reports = $conn->query($reports_query)->fetch_all(MYSQLI_ASSOC);
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4 align-items-center">
    <div class="col-lg-8">
        <h1 class="section-title">Admin Dashboard</h1>
        <p class="text-muted mb-0">Phase 5 - Role-based access control, user management, product moderation, and fraud monitoring.</p>
    </div>
    <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
        <span class="badge bg-dark px-3 py-2">RBAC: Admin only</span>
    </div>
</div>

<?php if (!empty($_SESSION['success_message'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (!empty($_SESSION['error_message'])): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row g-3 mb-4">
    <div class="col-md-6 col-lg-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: var(--primary-color);">👥</div>
            <div class="stat-content">
                <p class="stat-label">Total Users</p>
                <h3 class="stat-value"><?php echo (int)$stats['total_users']; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #27ae60;">✅</div>
            <div class="stat-content">
                <p class="stat-label">Active Users</p>
                <h3 class="stat-value"><?php echo (int)$stats['active_users']; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #f39c12;">📋</div>
            <div class="stat-content">
                <p class="stat-label">Pending Listings</p>
                <h3 class="stat-value"><?php echo (int)$stats['pending_products']; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #e74c3c;">🚨</div>
            <div class="stat-content">
                <p class="stat-label">Open Reports</p>
                <h3 class="stat-value"><?php echo (int)$stats['open_reports']; ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-lg-6 mb-3">
        <div class="dashboard-card">
            <h5 class="card-title">RBAC Overview</h5>
            <div class="role-grid">
                <?php foreach ($role_options as $role): ?>
                    <?php
                    $count = 0;
                    foreach ($role_counts as $role_count) {
                        if ($role_count['user_type'] === $role) {
                            $count = (int)$role_count['total'];
                            break;
                        }
                    }
                    ?>
                    <div class="role-pill">
                        <span class="role-name"><?php echo ucfirst($role); ?></span>
                        <span class="role-count"><?php echo $count; ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <p class="text-muted mt-3 mb-0">Use role changes below to control platform access. Admins can manage buyers, sellers, and other admins.</p>
        </div>
    </div>

    <div class="col-lg-6 mb-3">
        <div class="dashboard-card">
            <h5 class="card-title">Platform Snapshot</h5>
            <div class="d-flex flex-wrap gap-3">
                <div><strong><?php echo (int)$stats['total_products']; ?></strong> products</div>
                <div><strong><?php echo (int)$stats['total_orders']; ?></strong> orders</div>
                <div><strong><?php echo (int)$stats['total_users']; ?></strong> accounts</div>
            </div>
            <hr>
            <div class="d-flex flex-wrap gap-2">
                <a class="btn btn-outline-primary btn-sm" href="#user-management">User Management</a>
                <a class="btn btn-outline-primary btn-sm" href="#product-moderation">Product Moderation</a>
                <a class="btn btn-outline-primary btn-sm" href="#fraud-reports">Fraud Reports</a>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4" id="user-management">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h5 class="card-title mb-0">User Management</h5>
                <span class="badge bg-light text-dark">RBAC + account controls</span>
            </div>

            <form method="GET" class="row g-3 mb-4">
                <div class="col-lg-4">
                    <input type="text" name="user_search" class="form-control" placeholder="Search users by name, email, or username" value="<?php echo htmlspecialchars($user_search); ?>">
                </div>
                <div class="col-lg-3">
                    <select name="user_role" class="form-select">
                        <option value="">All Roles</option>
                        <?php foreach ($role_options as $role): ?>
                            <option value="<?php echo $role; ?>" <?php echo $user_role_filter === $role ? 'selected' : ''; ?>><?php echo ucfirst($role); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-3">
                    <select name="user_status" class="form-select">
                        <option value="">All Statuses</option>
                        <?php foreach ($user_status_options as $status): ?>
                            <option value="<?php echo $status; ?>" <?php echo $user_status_filter === $status ? 'selected' : ''; ?>><?php echo ucfirst($status); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                                <small class="text-muted"><?php echo htmlspecialchars($user['username']); ?> · <?php echo htmlspecialchars($user['email']); ?></small>
                            </td>
                            <td><span class="badge bg-dark"><?php echo ucfirst($user['user_type']); ?></span></td>
                            <td>
                                <span class="badge <?php echo $user['status'] === 'active' ? 'bg-success' : ($user['status'] === 'suspended' ? 'bg-warning text-dark' : 'bg-secondary'); ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                            <td>
                                <div class="d-flex flex-wrap gap-2">
                                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#roleModal<?php echo $user['user_id']; ?>">Role</button>
                                    <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#statusModal<?php echo $user['user_id']; ?>">Status</button>
                                </div>
                            </td>
                        </tr>

                        <div class="modal fade" id="roleModal<?php echo $user['user_id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Update Role</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST">
                                        <div class="modal-body">
                                            <input type="hidden" name="action" value="update_user_role">
                                            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                            <p class="mb-2"><strong><?php echo htmlspecialchars($user['full_name']); ?></strong></p>
                                            <select name="new_role" class="form-select">
                                                <?php foreach ($role_options as $role): ?>
                                                    <option value="<?php echo $role; ?>" <?php echo $user['user_type'] === $role ? 'selected' : ''; ?>><?php echo ucfirst($role); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Role</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="statusModal<?php echo $user['user_id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Update Status</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST">
                                        <div class="modal-body">
                                            <input type="hidden" name="action" value="update_user_status">
                                            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                            <p class="mb-2"><strong><?php echo htmlspecialchars($user['full_name']); ?></strong></p>
                                            <select name="new_status" class="form-select">
                                                <?php foreach ($user_status_options as $status): ?>
                                                    <option value="<?php echo $status; ?>" <?php echo $user['status'] === $status ? 'selected' : ''; ?>><?php echo ucfirst($status); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Status</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($user_total_pages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center mb-0">
                    <?php for ($i = 1; $i <= $user_total_pages; $i++): ?>
                    <li class="page-item <?php echo $i === $user_page ? 'active' : ''; ?>">
                        <a class="page-link" href="?user_page=<?php echo $i; ?>&product_page=<?php echo $product_page; ?><?php echo $user_search !== '' ? '&user_search=' . urlencode($user_search) : ''; ?><?php echo $user_role_filter !== '' ? '&user_role=' . urlencode($user_role_filter) : ''; ?><?php echo $user_status_filter !== '' ? '&user_status=' . urlencode($user_status_filter) : ''; ?><?php echo $product_search !== '' ? '&product_search=' . urlencode($product_search) : ''; ?><?php echo $product_status_filter !== '' ? '&product_status=' . urlencode($product_status_filter) : ''; ?><?php echo $report_status_filter !== '' ? '&report_status=' . urlencode($report_status_filter) : ''; ?>"><?php echo $i; ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row mb-4" id="product-moderation">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h5 class="card-title mb-0">Product Moderation</h5>
                <span class="badge bg-light text-dark">Approve, activate, deactivate, or mark sold</span>
            </div>

            <form method="GET" class="row g-3 mb-4">
                <div class="col-lg-6">
                    <input type="text" name="product_search" class="form-control" placeholder="Search products or sellers" value="<?php echo htmlspecialchars($product_search); ?>">
                </div>
                <div class="col-lg-4">
                    <select name="product_status" class="form-select">
                        <option value="">All Product Statuses</option>
                        <?php foreach ($product_status_options as $status): ?>
                            <option value="<?php echo $status; ?>" <?php echo $product_status_filter === $status ? 'selected' : ''; ?>><?php echo ucfirst(str_replace('_', ' ', $status)); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Seller</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($product['product_name']); ?></strong><br>
                                <small class="text-muted">Stock: <?php echo (int)$product['quantity_available']; ?></small>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($product['seller_name']); ?><br>
                                <small class="text-muted">@<?php echo htmlspecialchars($product['seller_username']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($product['category']); ?></td>
                            <td><?php echo formatCurrency($product['price']); ?></td>
                            <td>
                                <span class="badge <?php echo $product['status'] === 'active' ? 'bg-success' : ($product['status'] === 'pending_approval' ? 'bg-warning text-dark' : ($product['status'] === 'sold' ? 'bg-dark' : 'bg-secondary')); ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $product['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#productModal<?php echo $product['product_id']; ?>">Moderate</button>
                            </td>
                        </tr>

                        <div class="modal fade" id="productModal<?php echo $product['product_id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Moderate Product</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST">
                                        <div class="modal-body">
                                            <input type="hidden" name="action" value="update_product_status">
                                            <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                                            <p class="mb-2"><strong><?php echo htmlspecialchars($product['product_name']); ?></strong></p>
                                            <select name="new_status" class="form-select">
                                                <?php foreach ($product_status_options as $status): ?>
                                                    <option value="<?php echo $status; ?>" <?php echo $product['status'] === $status ? 'selected' : ''; ?>><?php echo ucfirst(str_replace('_', ' ', $status)); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <small class="form-text text-muted d-block mt-2">Use pending approval for listings that need review, active for approved listings, inactive for hidden listings, and sold when completed.</small>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Status</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($product_total_pages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center mb-0">
                    <?php for ($i = 1; $i <= $product_total_pages; $i++): ?>
                    <li class="page-item <?php echo $i === $product_page ? 'active' : ''; ?>">
                        <a class="page-link" href="?product_page=<?php echo $i; ?>&user_page=<?php echo $user_page; ?><?php echo $user_search !== '' ? '&user_search=' . urlencode($user_search) : ''; ?><?php echo $user_role_filter !== '' ? '&user_role=' . urlencode($user_role_filter) : ''; ?><?php echo $user_status_filter !== '' ? '&user_status=' . urlencode($user_status_filter) : ''; ?><?php echo $product_search !== '' ? '&product_search=' . urlencode($product_search) : ''; ?><?php echo $product_status_filter !== '' ? '&product_status=' . urlencode($product_status_filter) : ''; ?><?php echo $report_status_filter !== '' ? '&report_status=' . urlencode($report_status_filter) : ''; ?>"><?php echo $i; ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row mb-4" id="fraud-reports">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h5 class="card-title mb-0">Fraud & Abuse Reports</h5>
                <span class="badge bg-light text-dark">Moderator review queue</span>
            </div>

            <form method="GET" class="row g-3 mb-4">
                <div class="col-lg-4">
                    <select name="report_status" class="form-select">
                        <option value="">All Report Statuses</option>
                        <?php foreach ($report_status_options as $status): ?>
                            <option value="<?php echo $status; ?>" <?php echo $report_status_filter === $status ? 'selected' : ''; ?>><?php echo ucfirst($status); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-8 d-flex justify-content-end align-items-center">
                    <button type="submit" class="btn btn-primary">Filter Reports</button>
                </div>
            </form>

            <?php if (!empty($reports)): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Report</th>
                            <th>Reported User</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reports as $report): ?>
                        <tr>
                            <td>
                                <strong><?php echo ucfirst(str_replace('_', ' ', $report['report_type'])); ?></strong><br>
                                <small class="text-muted"><?php echo htmlspecialchars(substr($report['description'], 0, 70)); ?><?php echo strlen($report['description']) > 70 ? '...' : ''; ?></small><br>
                                <small class="text-muted">Reporter: <?php echo htmlspecialchars($report['reporter_username']); ?></small>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($report['reported_username']); ?><br>
                                <small class="text-muted"><?php echo $report['product_name'] ? 'Product: ' . htmlspecialchars($report['product_name']) : 'No product linked'; ?></small>
                            </td>
                            <td><span class="badge bg-warning text-dark"><?php echo ucfirst($report['status']); ?></span></td>
                            <td><?php echo date('M d, Y', strtotime($report['created_at'])); ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#reportModal<?php echo $report['report_id']; ?>">Review</button>
                            </td>
                        </tr>

                        <div class="modal fade" id="reportModal<?php echo $report['report_id']; ?>" tabindex="-1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Review Fraud Report</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST">
                                        <div class="modal-body">
                                            <input type="hidden" name="action" value="update_report_status">
                                            <input type="hidden" name="report_id" value="<?php echo $report['report_id']; ?>">
                                            <p><strong>Type:</strong> <?php echo ucfirst(str_replace('_', ' ', $report['report_type'])); ?></p>
                                            <p><strong>Reporter:</strong> <?php echo htmlspecialchars($report['reporter_username']); ?></p>
                                            <p><strong>Reported User:</strong> <?php echo htmlspecialchars($report['reported_username']); ?></p>
                                            <p><strong>Target:</strong> <?php echo $report['product_name'] ? htmlspecialchars($report['product_name']) : 'N/A'; ?></p>
                                            <p><strong>Description:</strong><br><?php echo nl2br(htmlspecialchars($report['description'])); ?></p>
                                            <div class="mb-3">
                                                <label class="form-label">Status</label>
                                                <select name="new_status" class="form-select">
                                                    <?php foreach ($report_status_options as $status): ?>
                                                        <option value="<?php echo $status; ?>" <?php echo $report['status'] === $status ? 'selected' : ''; ?>><?php echo ucfirst($status); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Admin Notes</label>
                                                <textarea name="admin_notes" class="form-control" rows="4"><?php echo htmlspecialchars($report['admin_notes'] ?? ''); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Review</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-muted mb-0">No fraud reports found for the selected filter.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.dashboard-card {
    background: white;
    border-radius: 10px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.card-title {
    font-weight: 700;
    color: var(--dark-text);
}

.role-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 0.75rem;
}

.role-pill {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 1rem;
    border: 1px solid var(--border-light);
    border-radius: 8px;
    background: var(--light-bg);
}

.role-name {
    font-weight: 600;
}

.role-count {
    background: var(--primary-color);
    color: white;
    border-radius: 999px;
    padding: 0.15rem 0.55rem;
    font-size: 0.85rem;
    font-weight: 700;
}

.stat-card {
    background: white;
    border-radius: 8px;
    padding: 1.25rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.stat-icon {
    width: 56px;
    height: 56px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.4rem;
}

.stat-label {
    margin: 0;
    color: var(--text-muted);
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    font-weight: 600;
}

.stat-value {
    margin: 0.35rem 0 0 0;
    font-size: 1.8rem;
    font-weight: 800;
    color: var(--dark-text);
}
</style>

<?php require_once 'includes/footer.php'; ?>
