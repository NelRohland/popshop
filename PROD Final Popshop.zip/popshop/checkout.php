<?php
$page_title = 'Checkout';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    redirect(APP_URL . '/login.php');
}

$db = new Database();
$mysqli = $db->getConnection();
$user_id = getUserId();

// Handle add to cart from product page
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $quantity = max(1, (int)($_POST['quantity'] ?? 1));

    $stmt = $mysqli->prepare("SELECT * FROM products WHERE product_id = ? AND status = 'active'");
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();

    if ($product) {
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['product_id'] == $product_id) {
                $item['quantity'] = min($item['quantity'] + $quantity, $product['quantity_available']);
                $found = true;
                break;
            }
        }
        unset($item);
        if (!$found) {
            $_SESSION['cart'][] = [
                'product_id'  => $product_id,
                'quantity'    => min($quantity, $product['quantity_available']),
                'product_name'=> $product['product_name'],
                'price'       => $product['price'],
                'main_image'  => $product['main_image'],
                'seller_id'   => $product['seller_id'],
            ];
        }
        $_SESSION['success_message'] = 'Item added to cart!';
    }
    header('Location: ' . APP_URL . '/checkout.php');
    exit;
}

// Handle remove from cart
if (isset($_GET['remove'])) {
    $remove_id = (int)$_GET['remove'];
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $k => $item) {
            if ($item['product_id'] == $remove_id) {
                array_splice($_SESSION['cart'], $k, 1);
                break;
            }
        }
    }
    header('Location: ' . APP_URL . '/checkout.php');
    exit;
}

// Handle update quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as &$item) {
            $pid = $item['product_id'];
            if (isset($_POST['qty_' . $pid])) {
                $new_qty = max(1, (int)$_POST['qty_' . $pid]);
                $item['quantity'] = $new_qty;
            }
        }
        unset($item);
    }
    header('Location: ' . APP_URL . '/checkout.php');
    exit;
}

// Handle checkout submit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $_SESSION['error_message'] = 'Security validation failed.';
        header('Location: ' . APP_URL . '/checkout.php');
        exit;
    }

    $delivery_address     = sanitize($_POST['delivery_address'] ?? '');
    $delivery_city        = sanitize($_POST['delivery_city'] ?? '');
    $delivery_province    = sanitize($_POST['delivery_province'] ?? '');
    $delivery_postal_code = sanitize($_POST['delivery_postal_code'] ?? '');
    $payment_method       = sanitize($_POST['payment_method'] ?? '');
    $notes                = sanitize($_POST['notes'] ?? '');

    $errors = [];
    if (empty($delivery_address))     $errors[] = 'Delivery address is required.';
    if (empty($delivery_city))        $errors[] = 'City is required.';
    if (empty($delivery_province))    $errors[] = 'Province is required.';
    if (empty($delivery_postal_code)) $errors[] = 'Postal code is required.';
    if (empty($payment_method))       $errors[] = 'Payment method is required.';
    if (empty($_SESSION['cart']))     $errors[] = 'Your cart is empty.';

    if (empty($errors)) {
        $_SESSION['pending_checkout']=$_POST;
        header('Location: '.APP_URL.'/payment_gateway.php');
        exit;
    } else {
        $_SESSION['error_message'] = implode(' ', $errors);
    }
}

// Get user info for pre-filling
$user_stmt = $mysqli->prepare("SELECT full_name, address, city, province, postal_code FROM users WHERE user_id = ?");
$user_stmt->bind_param('i', $user_id);
$user_stmt->execute();
$user_info = $user_stmt->get_result()->fetch_assoc();

$cart = $_SESSION['cart'] ?? [];
$cart_total = 0;
foreach ($cart as $item) $cart_total += $item['price'] * $item['quantity'];

$csrf_token = generateCSRFToken();
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="section-title">Checkout</h1>
    </div>
</div>

<?php if (!empty($_SESSION['success_message'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (!empty($_SESSION['error_message'])): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (empty($cart)): ?>
<div class="no-results">
    <div class="no-results-icon">🛒</div>
    <h4>Your Cart is Empty</h4>
    <p class="no-results-text">Browse products and add items to your cart.</p>
    <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-primary mt-3">Browse Marketplace</a>
</div>
<?php else: ?>
<div class="row">
    <!-- Cart Items -->
    <div class="col-lg-7">
        <div class="checkout-card mb-4">
            <h5 class="checkout-section-title">Cart Items (<?php echo count($cart); ?>)</h5>

            <form method="POST">
            <?php foreach ($cart as $item): ?>
            <div class="cart-item">
                <div class="cart-item-image">
                    <?php if (!empty($item['main_image'])): ?>
                        <img src="<?php echo APP_URL; ?>/<?php echo htmlspecialchars($item['main_image']); ?>"
                             alt="<?php echo htmlspecialchars($item['product_name']); ?>"
                             onerror="this.src='<?php echo APP_URL; ?>/assets/placeholder.png'">
                    <?php else: ?>
                        <div class="cart-no-image">No Image</div>
                    <?php endif; ?>
                </div>
                <div class="cart-item-details">
                    <p class="cart-item-name"><?php echo htmlspecialchars($item['product_name']); ?></p>
                    <p class="cart-item-price"><?php echo formatCurrency($item['price']); ?> each</p>
                    <div class="d-flex align-items-center gap-2 mt-2">
                        <label class="form-label mb-0" style="font-size:0.85rem;">Qty:</label>
                        <input type="number" name="qty_<?php echo $item['product_id']; ?>"
                               class="form-control form-control-sm" style="width:70px;"
                               value="<?php echo $item['quantity']; ?>" min="1">
                    </div>
                </div>
                <div class="cart-item-total">
                    <p class="cart-subtotal"><?php echo formatCurrency($item['price'] * $item['quantity']); ?></p>
                    <a href="<?php echo APP_URL; ?>/checkout.php?remove=<?php echo $item['product_id']; ?>"
                       class="btn btn-sm btn-outline-danger mt-2"
                       onclick="return confirm('Remove this item?')">Remove</a>
                </div>
            </div>
            <?php endforeach; ?>

            <div class="d-flex justify-content-between mt-3">
                <button type="submit" name="update_cart" class="btn btn-outline-secondary btn-sm">Update Cart</button>
                <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-outline-primary btn-sm">Continue Shopping</a>
            </div>
            </form>
        </div>

        <!-- Delivery Details -->
        <div class="checkout-card">
            <h5 class="checkout-section-title">Delivery Details</h5>
            <form method="POST" id="checkoutForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="place_order" value="1">

                <div class="mb-3">
                    <label class="form-label">Delivery Address *</label>
                    <input type="text" name="delivery_address" class="form-control" required
                           placeholder="Street address" value="<?php echo htmlspecialchars($user_info['address'] ?? ''); ?>">
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">City *</label>
                        <input type="text" name="delivery_city" class="form-control" required
                               placeholder="City" value="<?php echo htmlspecialchars($user_info['city'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Province *</label>
                        <select name="delivery_province" class="form-select" required>
                            <option value="">Select Province</option>
                            <?php
                            $provinces = ['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape'];
                            $saved_province = $user_info['province'] ?? '';
                            foreach ($provinces as $p):
                            ?>
                            <option value="<?php echo $p; ?>" <?php echo $saved_province === $p ? 'selected' : ''; ?>>
                                <?php echo $p; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Postal Code *</label>
                        <input type="text" name="delivery_postal_code" class="form-control" required
                               placeholder="0000" maxlength="10"
                               value="<?php echo htmlspecialchars($user_info['postal_code'] ?? ''); ?>">
                    </div>
                    <div class="col-md-8">
                        <label class="form-label">Payment Method *</label>
                        <select name="payment_method" class="form-select" required>
                            <option value="">Select Payment Method</option>
                            <option value="EFT">EFT (Bank Transfer)</option>
                            <option value="Cash on Delivery">Cash on Delivery</option>
                            <option value="SnapScan">SnapScan</option>
                            <option value="Ozow">Ozow</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Order Notes (optional)</label>
                    <textarea name="notes" class="form-control" rows="3" placeholder="Any special instructions..."></textarea>
                </div>
            </form>
        </div>
    </div>

    <!-- Order Summary -->
    <div class="col-lg-5">
        <div class="checkout-card order-summary sticky-top" style="top: 1rem;">
            <h5 class="checkout-section-title">Order Summary</h5>

            <?php foreach ($cart as $item): ?>
            <div class="summary-item">
                <span><?php echo htmlspecialchars(substr($item['product_name'], 0, 28)); ?> x<?php echo $item['quantity']; ?></span>
                <span><?php echo formatCurrency($item['price'] * $item['quantity']); ?></span>
            </div>
            <?php endforeach; ?>

            <hr>

            <div class="summary-item">
                <span>Subtotal</span>
                <span><?php echo formatCurrency($cart_total); ?></span>
            </div>
            <div class="summary-item text-muted" style="font-size:0.9rem;">
                <span>Delivery</span>
                <span>Arranged with seller</span>
            </div>

            <hr>

            <div class="summary-item summary-total">
                <span>Total</span>
                <span><?php echo formatCurrency($cart_total); ?></span>
            </div>

            <button type="submit" form="checkoutForm" class="btn btn-primary btn-lg w-100 mt-3">
                Place Order
            </button>

            <p class="text-muted text-center mt-2" style="font-size:0.8rem;">
                By placing your order you agree to our terms and conditions.
            </p>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
.checkout-card {
    background: white;
    border-radius: 10px;
    padding: 1.75rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.checkout-section-title {
    font-weight: 700;
    margin-bottom: 1.25rem;
    color: var(--dark-text);
    padding-bottom: 0.75rem;
    border-bottom: 2px solid var(--border-light);
}

.cart-item {
    display: flex;
    gap: 1rem;
    padding: 1rem 0;
    border-bottom: 1px solid var(--border-light);
}

.cart-item:last-child {
    border-bottom: none;
}

.cart-item-image {
    width: 80px;
    height: 80px;
    border-radius: 8px;
    overflow: hidden;
    flex-shrink: 0;
    background: var(--light-bg);
}

.cart-item-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.cart-no-image {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    color: var(--text-muted);
}

.cart-item-details {
    flex: 1;
}

.cart-item-name {
    font-weight: 600;
    margin: 0 0 0.25rem 0;
    color: var(--dark-text);
}

.cart-item-price {
    margin: 0;
    color: var(--text-muted);
    font-size: 0.9rem;
}

.cart-item-total {
    text-align: right;
    flex-shrink: 0;
}

.cart-subtotal {
    font-weight: 700;
    color: var(--primary-color);
    margin: 0;
    font-size: 1.05rem;
}

.summary-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.75rem;
    color: var(--dark-text);
}

.summary-total {
    font-weight: 700;
    font-size: 1.1rem;
}

.form-label {
    font-weight: 600;
    color: var(--dark-text);
    margin-bottom: 0.4rem;
}
</style>

<?php require_once 'includes/footer.php'; ?>
