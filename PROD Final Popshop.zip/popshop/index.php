<?php
$page_title = 'Home';
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<?php require_once 'includes/header.php'; ?>

<div class="row">
    <div class="col-md-8">
        <div class="jumbotron bg-light p-5 rounded-lg">
            <h1 class="display-4">Welcome to <?php echo APP_NAME; ?></h1>
            <p class="lead">Empowering informal traders and township entrepreneurs in South Africa with a safe digital marketplace.</p>
            <?php if (!isLoggedIn()): ?>
                <hr class="my-4">
                <p>Get started today!</p>
                <a class="btn btn-primary btn-lg me-2" href="register.php" role="button">Register</a>
                <a class="btn btn-outline-primary btn-lg" href="login.php" role="button">Login</a>
            <?php else: ?>
                <hr class="my-4">
                <p>Welcome back, <strong><?php echo sanitize($_SESSION['username']); ?></strong></p>
                <a class="btn btn-primary btn-lg me-2" href="browse_products.php" role="button">Browse Products</a>
                <?php if (hasRole('seller')): ?>
                    <a class="btn btn-outline-primary btn-lg" href="add_product.php" role="button">Add Product</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="mt-5">
            <h2>How it Works</h2>
            <div class="row mt-3">
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">For Buyers</h5>
                            <p class="card-text">Browse products from local sellers, compare prices, and make secure purchases from trusted traders in your community.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">For Sellers</h5>
                            <p class="card-text">List your products, manage your inventory, reach more customers, and grow your business safely online.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-light">
            <div class="card-body">
                <h5 class="card-title">Platform Features</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><strong>Safe Transactions</strong> - Secure payment processing</li>
                    <li class="mb-2"><strong>Direct Messaging</strong> - Communicate with buyers/sellers</li>
                    <li class="mb-2"><strong>Fraud Protection</strong> - Report and block suspicious users</li>
                    <li class="mb-2"><strong>Mobile Ready</strong> - Shop anytime, anywhere</li>
                    <li class="mb-2"><strong>Local Community</strong> - Support local traders</li>
                </ul>
            </div>
        </div>

        <?php if (isLoggedIn() && isAdmin()): ?>
            <div class="card bg-light mt-3">
                <div class="card-body">
                    <h5 class="card-title">Admin Panel</h5>
                    <a href="admin_page.php" class="btn btn-sm btn-danger w-100">Go to Admin</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
