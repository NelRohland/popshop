<?php

require_once "includes/config.php";
require_once "includes/db_connect.php";
require_once "includes/functions.php";

if (!isLoggedIn()) {
    redirect('login.php');
}

$db = new Database();
$mysqli = $db->getConnection();
$uid = $_SESSION["user_id"];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $rid = (int) $_POST["receiver_id"];
    $subject = sanitize($_POST["subject"] ?? '');
    $msg = sanitize($_POST["message_content"]);

    if ($rid && $msg) {
        $st = $mysqli->prepare("
            INSERT INTO messages (
                sender_id,
                receiver_id,
                subject,
                message_content
            ) VALUES (?, ?, ?, ?)
        ");

        $st->bind_param("iiss", $uid, $rid, $subject, $msg);
        $st->execute();
        $_SESSION['success_message'] = "Message sent successfully!";
    } else {
        $_SESSION['error_message'] = "Recipient and message are required.";
    }
}

include "includes/header.php";
?>

<div class="container mt-4">
    <h2>Messages</h2>

    <?php include "includes/error_msg.php"; ?>

    <div class="row">
        <div class="col-md-4">
            <h4>Send New Message</h4>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Receiver User ID</label>
                    <input
                        type="number"
                        name="receiver_id"
                        class="form-control"
                        placeholder="User ID"
                        required
                    >
                </div>

                <div class="mb-3">
                    <label class="form-label">Subject</label>
                    <input
                        type="text"
                        name="subject"
                        class="form-control"
                        placeholder="Subject (optional)"
                    >
                </div>

                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea
                        name="message_content"
                        class="form-control"
                        rows="5"
                        required
                    ></textarea>
                </div>

                <button type="submit" class="btn btn-primary">
                    Send Message
                </button>
            </form>
        </div>
        <div class="col-md-8">
            <h4>Your Messages</h4>
            <?php
            $stmt = $mysqli->prepare("
                SELECT m.*, u.username as sender_name 
                FROM messages m 
                JOIN users u ON m.sender_id = u.user_id 
                WHERE m.receiver_id = ? 
                ORDER BY m.sent_at DESC
            ");
            $stmt->bind_param("i", $uid);
            $stmt->execute();
            $res = $stmt->get_result();
            $msgs = $res->fetch_all(MYSQLI_ASSOC);

            if (empty($msgs)):
            ?>
                <p class="text-muted">No messages yet.</p>
            <?php else: ?>
                <div class="list-group">
                    <?php foreach ($msgs as $m): ?>
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1">
                                    <?php if (!empty($m['subject'])): ?>
                                        <strong><?php echo htmlspecialchars($m['subject']); ?></strong><br>
                                    <?php endif; ?>
                                    <small class="text-muted">From: <?php echo htmlspecialchars($m['sender_name']); ?></small>
                                </h5>
                                <small><?php echo $m['sent_at']; ?></small>
                            </div>
                            <p class="mb-1 mt-2"><?php echo nl2br(htmlspecialchars($m['message_content'])); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>