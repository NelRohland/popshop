<?php
/**
 * Register Logic
 * Handles user registration form submission
 */

require_once dirname(__FILE__) . '/db_connect.php';
require_once dirname(__FILE__) . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('Invalid request method');
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_msg'] = 'Security validation failed. Please try again.';
    redirect(APP_URL . '/register.php');
}

// Get form data
$username = sanitize($_POST['username'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$full_name = sanitize($_POST['full_name'] ?? '');
$user_type = sanitize($_POST['user_type'] ?? '');

// Validation
$errors = [];

if (empty($username)) {
    $errors[] = 'Username is required';
} elseif (strlen($username) < 3 || strlen($username) > 50) {
    $errors[] = 'Username must be 3-50 characters long';
}

if (empty($email)) {
    $errors[] = 'Email is required';
} elseif (!validateEmail($email)) {
    $errors[] = 'Email is invalid';
}

if (empty($password)) {
    $errors[] = 'Password is required';
} elseif (!validatePassword($password)) {
    $errors[] = 'Password must be at least 8 characters with uppercase, lowercase, and digits';
}

if ($password !== $confirm_password) {
    $errors[] = 'Passwords do not match';
}

if (empty($full_name)) {
    $errors[] = 'Full name is required';
} elseif (strlen($full_name) > 100) {
    $errors[] = 'Full name is too long';
}

if (!in_array($user_type, ['buyer', 'seller'])) {
    $errors[] = 'Invalid user type';
}

if (!empty($errors)) {
    $_SESSION['error_msg'] = implode('<br>', $errors);
    // Store form data (except passwords) in session for re-population
    $_SESSION['form_data'] = [
        'full_name' => $full_name,
        'username' => $username,
        'email' => $email,
        'user_type' => $user_type
    ];
    redirect(APP_URL . '/register.php');
}

// Check if username already exists
$stmt = $db->prepare("SELECT user_id FROM users WHERE username = ?");
$stmt->bind_param('s', $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['error_msg'] = 'Username already exists. Please choose another.';
    redirect(APP_URL . '/register.php');
}

// Check if email already exists
$stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['error_msg'] = 'Email already registered. Please use another or login.';
    redirect(APP_URL . '/register.php');
}

// Hash password
$password_hash = hashPassword($password);

// Create user
$stmt = $db->prepare("INSERT INTO users (username, email, password_hash, full_name, user_type) VALUES (?, ?, ?, ?, ?)");

if (!$stmt) {
    $_SESSION['error_msg'] = 'Database error. Please try again later.';
    redirect(APP_URL . '/register.php');
}

$stmt->bind_param('sssss', $username, $email, $password_hash, $full_name, $user_type);

if ($stmt->execute()) {
    $_SESSION['success_msg'] = 'Registration successful! Please login with your credentials.';
    redirect(APP_URL . '/login.php');
} else {
    $_SESSION['error_msg'] = 'Registration failed. Please try again.';
    redirect(APP_URL . '/register.php');
}

?>
