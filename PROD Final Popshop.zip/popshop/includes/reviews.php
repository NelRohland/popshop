<?php
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

function submitProductReview($productId, $buyerId, $content) {
    global $db;
    $sql = "INSERT INTO product_reviews (product_id, buyer_id, content, approved) VALUES (?, ?, ?, 0)";
    $stmt = $db->prepare($sql);
    $db->execute($stmt, 'iis', [$productId, $buyerId, $content]);
    return $db->getLastInsertId();
}

function getApprovedReviews($productId) {
    global $db;
    $sql = "SELECT pr.*, u.username FROM product_reviews pr JOIN users u ON pr.buyer_id = u.user_id WHERE pr.product_id = ? AND pr.approved = 1 ORDER BY pr.created_at DESC";
    $stmt = $db->prepare($sql);
    $db->execute($stmt, 'i', [$productId]);
    $res = $db->getResult($stmt);
    return $db->fetchAll($res);
}

?>
