<?php
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

function submitSellerRating($sellerId, $buyerId, $rating) {
    global $db;
    $sql = "INSERT INTO seller_ratings (seller_id, buyer_id, rating) VALUES (?, ?, ?)";
    $stmt = $db->prepare($sql);
    $db->execute($stmt, 'iii', [$sellerId, $buyerId, $rating]);
    return $db->getLastInsertId();
}

function getSellerAverageRating($sellerId) {
    global $db;
    $sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM seller_ratings WHERE seller_id = ?";
    $stmt = $db->prepare($sql);
    $db->execute($stmt, 'i', [$sellerId]);
    $res = $db->getResult($stmt);
    return $db->fetch($res);
}

function getRatingsBySeller($sellerId) {
    global $db;
    $sql = "SELECT sr.*, u.username as buyer_name FROM seller_ratings sr JOIN users u ON sr.buyer_id = u.user_id WHERE sr.seller_id = ? ORDER BY sr.created_at DESC";
    $stmt = $db->prepare($sql);
    $db->execute($stmt, 'i', [$sellerId]);
    $res = $db->getResult($stmt);
    return $db->fetchAll($res);
}

?>
