<?php
/**
 * Helper Functions
 * Reusable functions throughout the application
 */

/**
 * Hash a password using bcrypt
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
}

/**
 * Verify a password against a hash
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Validate email format
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validate password strength
 */
function validatePassword($password) {
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return false;
    }
    return preg_match(PASSWORD_REGEX, $password);
}

/**
 * Sanitize user input
 */
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Redirect to a page
 */
function redirect($url) {
    header("Location: " . $url);
    exit();
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get logged in user ID
 */
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get logged in user type
 */
function getUserType() {
    return $_SESSION['user_type'] ?? null;
}

/**
 * Check if user has specific role
 */
function hasRole($role) {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === $role;
}

/**
 * Check if user is admin
 */
function isAdmin() {
    $userType = getUserType();
    return $userType === 'admin';
}

/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Format currency (ZAR)
 */
function formatCurrency($amount) {
    return 'R ' . number_format((float)$amount, 2, '.', ',');
}

/**
 * Format date
 */
function formatDate($date, $format = 'Y-m-d H:i') {
    if (empty($date)) return '';
    return date($format, strtotime($date));
}

/**
 * Time ago function
 */
function timeAgo($date) {
    $time = strtotime($date);
    $currentTime = time();
    $difference = $currentTime - $time;

    if ($difference < 60) {
        return $difference . ' seconds ago';
    } elseif ($difference < 3600) {
        $minutes = floor($difference / 60);
        return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
    } elseif ($difference < 86400) {
        $hours = floor($difference / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($difference < 604800) {
        $days = floor($difference / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return formatDate($date, 'M d, Y');
    }
}

/**
 * Log user activity
 */
function logActivity($action, $entityType, $entityId = null, $oldValue = null, $newValue = null) {
    global $db;

    if (!isAdmin()) return false;

    $adminId = getUserId();
    $ipAddress = $_SERVER['REMOTE_ADDR'];

    $oldValueJson = $oldValue ? json_encode($oldValue) : null;
    $newValueJson = $newValue ? json_encode($newValue) : null;

    $sql = "INSERT INTO audit_logs (admin_id, action, entity_type, entity_id, old_value, new_value, ip_address) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $db->prepare($sql);
    $db->execute($stmt, 'issssss', [$adminId, $action, $entityType, $entityId, $oldValueJson, $newValueJson, $ipAddress]);

    return true;
}

/**
 * Validate file upload
 */
function validateFileUpload($file) {
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'message' => 'File size exceeds limit'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, ALLOWED_EXTENSIONS)) {
        return ['success' => false, 'message' => 'Invalid file type'];
    }

    return ['success' => true];
}

/**
 * Save uploaded file
 */
function saveUploadedFile($file) {
    $validation = validateFileUpload($file);

    if (!$validation['success']) {
        return $validation;
    }

    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }

    $fileName = uniqid() . '_' . basename($file['name']);
    $filePath = UPLOAD_DIR . $fileName;

    if (!move_uploaded_file($file['tmp_name'], $filePath)) {
        return ['success' => false, 'message' => 'Failed to save file'];
    }

    return ['success' => true, 'filename' => $fileName, 'path' => 'uploads/' . $fileName];
}

?>
