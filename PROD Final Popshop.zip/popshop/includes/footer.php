<?php
/**
 * Footer Include
 * Common footer for all pages
 */
?>
</main>

<footer class="bg-dark text-light mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <h5><?php echo APP_NAME; ?></h5>
                <p class="small">Empowering informal traders and township entrepreneurs in South Africa.</p>
            </div>
            <div class="col-md-4 mb-3">
                <h5>Quick Links</h5>
                <ul class="list-unstyled small">
                    <li><a href="<?php echo APP_URL; ?>/index.php" class="text-light text-decoration-none">Home</a></li>
                    <li><a href="<?php echo APP_URL; ?>/browse_products.php" class="text-light text-decoration-none">Browse Products</a></li>
                    <li><a href="<?php echo APP_URL; ?>/login.php" class="text-light text-decoration-none">Login</a></li>
                </ul>
            </div>
            <div class="col-md-4 mb-3">
                <h5>Contact</h5>
                <p class="small">Email: support@popshop.co.za</p>
                <p class="small">Phone: +27 (0) 11 234 5678</p>
            </div>
        </div>
        <hr>
        <div class="text-center small">
            <p>&copy; 2026 <?php echo APP_NAME; ?>. All rights reserved. | <a href="#" class="text-light">Terms</a> | <a href="#" class="text-light">Privacy</a></p>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo APP_URL; ?>/assets/js/scripts.js"></script>
</body>
</html>
