<?php
/**
 * Fraud Report Logic
 * Handles fraud/abuse report form submission
 */

require_once dirname(__FILE__) . '/config.php';
require_once dirname(__FILE__) . '/db_connect.php';
require_once dirname(__FILE__) . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('Invalid request method');
}

if (!isLoggedIn()) {
    redirect(APP_URL . '/login.php');
}

if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_message'] = 'Security validation failed.';
    redirect(APP_URL . '/browse_products.php');
}

$db = new Database();
$mysqli = $db->getConnection();

$reporter_id      = getUserId();
$reported_user_id = (int)($_POST['reported_user_id'] ?? 0);
$report_type      = sanitize($_POST['report_type'] ?? '');
$description      = sanitize($_POST['description'] ?? '');
$product_id       = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : null;
$redirect_to      = sanitize($_POST['redirect_to'] ?? APP_URL . '/browse_products.php');

$valid_types = ['fraud', 'fake_product', 'abusive_behavior', 'inappropriate_content', 'other'];

if ($reporter_id == $reported_user_id) {
    $_SESSION['error_message'] = 'You cannot report yourself.';
    redirect($redirect_to);
}

if (!in_array($report_type, $valid_types)) {
    $_SESSION['error_message'] = 'Invalid report type.';
    redirect($redirect_to);
}

if (strlen($description) < 10) {
    $_SESSION['error_message'] = 'Please provide a more detailed description.';
    redirect($redirect_to);
}

// Check for duplicate report in last 24 hours
$dup = $mysqli->query("
    SELECT report_id FROM fraud_reports
    WHERE reporter_id = $reporter_id AND reported_user_id = $reported_user_id
      AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
    LIMIT 1
")->fetch_assoc();

if ($dup) {
    $_SESSION['error_message'] = 'You have already reported this user in the last 24 hours.';
    redirect($redirect_to);
}

$stmt = $mysqli->prepare("
    INSERT INTO fraud_reports (reporter_id, reported_user_id, report_type, description, product_id)
    VALUES (?, ?, ?, ?, ?)
");
$stmt->bind_param('iissi', $reporter_id, $reported_user_id, $report_type, $description, $product_id);

if ($stmt->execute()) {
    $_SESSION['success_message'] = 'Your report has been submitted. Our team will review it.';
} else {
    $_SESSION['error_message'] = 'Failed to submit report. Please try again.';
}

redirect($redirect_to);
?>
