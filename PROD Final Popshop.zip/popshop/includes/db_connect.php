<?php
/**
 * Database Connection Handler
 * Establishes MySQL connection and provides helper functions
 */

require_once 'config.php';

class Database {
    private $conn;
    private $error;

    public function __construct() {
        $this->connect();
    }

    public function connect() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        if ($this->conn->connect_error) {
            $this->error = "Connection Error: " . $this->conn->connect_error;
            return false;
        }

        $this->conn->set_charset("utf8mb4");
        return true;
    }

    public function getConnection() {
        return $this->conn;
    }

    public function query($sql) {
        $result = $this->conn->query($sql);

        if (!$result) {
            $this->error = $this->conn->error;
            return false;
        }

        return $result;
    }

    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }

    public function execute($stmt, $types = '', $params = []) {
        if (empty($types) || empty($params)) {
            if (!$stmt->execute()) {
                $this->error = $stmt->error;
                return false;
            }
        } else {
            if (!$stmt->bind_param($types, ...$params)) {
                $this->error = $stmt->error;
                return false;
            }

            if (!$stmt->execute()) {
                $this->error = $stmt->error;
                return false;
            }
        }

        return $stmt;
    }

    public function getResult($stmt) {
        return $stmt->get_result();
    }

    public function fetch($result) {
        return $result->fetch_assoc();
    }

    public function fetchAll($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getLastInsertId() {
        return $this->conn->insert_id;
    }

    public function getAffectedRows() {
        return $this->conn->affected_rows;
    }

    public function getError() {
        return $this->error;
    }

    public function close() {
        if ($this->conn) {
            $this->conn->close();
        }
    }

    public function escape($data) {
        return $this->conn->real_escape_string($data);
    }
}

$db = new Database();

?>
