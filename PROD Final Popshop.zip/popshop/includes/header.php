<?php
/**
 * Header Include
 * Common header for all pages
 */

if (!defined('APP_NAME')) {
    require_once dirname(__FILE__) . '/config.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . APP_NAME : APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/assets/css/styles.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo APP_URL; ?>/index.php">
            <img src="<?php echo APP_URL; ?>/assets/popshop-high-resolution-logo-transparent.png" alt="<?php echo APP_NAME; ?>" height="45">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if (isLoggedIn()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP_URL; ?>/index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP_URL; ?>/browse_products.php">Browse</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP_URL; ?>/checkout.php">
                            Cart
                            <?php $cart_count = count($_SESSION['cart'] ?? []); if ($cart_count > 0): ?>
                            <span class="badge" style="background-color:var(--primary-color);border-radius:999px;padding:2px 7px;font-size:0.75rem;"><?php echo $cart_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php if (hasRole('seller') || hasRole('admin')): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="sellerDropdown" role="button" data-bs-toggle="dropdown">
                                Sell
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="sellerDropdown">
                                <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/seller_dashboard.php">Dashboard</a></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/add_product.php">Add Product</a></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/user_listings.php">My Products</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/seller_orders.php">Orders</a></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/seller_inventory.php">Inventory</a></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/seller_analytics.php">Analytics</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (isAdmin()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo APP_URL; ?>/admin_page.php">Admin</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo APP_URL; ?>/messages.php">Messages</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <?php echo sanitize($_SESSION['username']); ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/user_listings.php">My Listings</a></li>
                            <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/my_orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP_URL; ?>/login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP_URL; ?>/register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="container mt-4">
