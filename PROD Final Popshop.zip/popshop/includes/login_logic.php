<?php
/**
 * Login Logic
 * Handles user login form submission with email, password, and remember me
 */

require_once dirname(__FILE__) . '/db_connect.php';
require_once dirname(__FILE__) . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('Invalid request method');
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_msg'] = 'Security validation failed. Please try again.';
    redirect(APP_URL . '/login.php');
}

// Get form data
$email = sanitize($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']) && $_POST['remember'] === 'on';

// Validation
if (empty($email)) {
    $_SESSION['error_msg'] = 'Email is required';
    redirect(APP_URL . '/login.php');
}

if (!validateEmail($email)) {
    $_SESSION['error_msg'] = 'Please enter a valid email address';
    redirect(APP_URL . '/login.php');
}

if (empty($password)) {
    $_SESSION['error_msg'] = 'Password is required';
    redirect(APP_URL . '/login.php');
}

// Get user from database by email
$db = new Database();
$stmt = $db->prepare("SELECT user_id, username, email, password_hash, user_type, status FROM users WHERE email = ?");

if (!$stmt) {
    $_SESSION['error_msg'] = 'Database error. Please try again later.';
    redirect(APP_URL . '/login.php');
}

$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error_msg'] = 'Invalid email or password';
    redirect(APP_URL . '/login.php');
}

$user = $result->fetch_assoc();

// Check account status
if ($user['status'] !== 'active') {
    $_SESSION['error_msg'] = 'Your account is ' . $user['status'] . '. Please contact support.';
    redirect(APP_URL . '/login.php');
}

// Verify password
if (!verifyPassword($password, $user['password_hash'])) {
    $_SESSION['error_msg'] = 'Invalid email or password';
    redirect(APP_URL . '/login.php');
}

// Login successful - set session
$_SESSION['user_id'] = $user['user_id'];
$_SESSION['username'] = $user['username'];
$_SESSION['email'] = $user['email'];
$_SESSION['user_type'] = $user['user_type'];

// Handle "Remember Me" - create persistent cookie
if ($remember) {
    $rememberToken = bin2hex(random_bytes(32));
    setcookie(
        COOKIE_NAME,
        $rememberToken,
        time() + REMEMBER_ME_DURATION,
        '/',
        '',
        false,
        true // HTTP only for security
    );
    
    // Store token hash in session for validation
    $_SESSION['remember_token'] = hash('sha256', $rememberToken);
}

// Update last login timestamp
$stmt = $db->prepare("UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE user_id = ?");
$stmt->bind_param('i', $user['user_id']);
$stmt->execute();

$_SESSION['success_msg'] = 'Login successful! Welcome back, ' . $user['username'];

// Redirect admins to admin panel, everyone else to index
if ($user['user_type'] === 'admin') {
    redirect(APP_URL . '/admin_page.php');
} else {
    redirect(APP_URL . '/index.php');
}

?>

