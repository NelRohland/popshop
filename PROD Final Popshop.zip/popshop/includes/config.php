<?php
/**
 * PopShop Configuration File
 * Contains database and application settings
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'popshop');

// Application Settings
define('APP_NAME', 'PopShop');
define('APP_URL', 'http://localhost/popshop');
define('APP_TIMEZONE', 'Africa/Johannesburg');

// Session Settings
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds

// File Upload Settings
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5242880); // 5MB in bytes
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);

// Security Settings
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REGEX', '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/'); // At least 1 lowercase, 1 uppercase, 1 digit, 8 chars

// Remember Me Settings
define('REMEMBER_ME_DURATION', 30 * 24 * 60 * 60); // 30 days in seconds D*H*M*S
define('COOKIE_NAME', 'popshop_remember_me');

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// Set Timezone
date_default_timezone_set(APP_TIMEZONE);

// Session Configuration
ini_set('session.gc_maxlifetime', SESSION_TIMEOUT);
session_start();

?>
