<?php
/**
 * Forgot Password Logic
 * Handles both email verification and password reset
 */

require_once dirname(__FILE__) . '/db_connect.php';
require_once dirname(__FILE__) . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('Invalid request method');
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_msg'] = 'Security validation failed. Please try again.';
    redirect(APP_URL . '/forgot_password.php');
}

$step = $_POST['step'] ?? '';

// Step 1: Verify Email
if ($step === 'verify_email') {
    $email = sanitize($_POST['email'] ?? '');

    // Validation
    if (empty($email)) {
        $_SESSION['error_msg'] = 'Email is required';
        redirect(APP_URL . '/forgot_password.php');
    }

    if (!validateEmail($email)) {
        $_SESSION['error_msg'] = 'Please enter a valid email address';
        redirect(APP_URL . '/forgot_password.php');
    }

    // Check if user exists
    $db = new Database();
    $stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");

    if (!$stmt) {
        $_SESSION['error_msg'] = 'Database error. Please try again later.';
        redirect(APP_URL . '/forgot_password.php');
    }

    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $_SESSION['error_msg'] = 'Email not found in our system';
        redirect(APP_URL . '/forgot_password.php');
    }

    // Email is valid, store in session and show reset form
    $_SESSION['reset_email'] = $email;
    redirect(APP_URL . '/forgot_password.php');
}

// Step 2: Reset Password
elseif ($step === 'reset_password') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Validate email
    if (empty($email) || !validateEmail($email)) {
        $_SESSION['error_msg'] = 'Invalid email address';
        unset($_SESSION['reset_email']);
        redirect(APP_URL . '/forgot_password.php');
    }

    // Validate password
    if (empty($password)) {
        $_SESSION['error_msg'] = 'Password is required';
        redirect(APP_URL . '/forgot_password.php');
    }

    if (!validatePassword($password)) {
        $_SESSION['error_msg'] = 'Password must be at least 8 characters with uppercase, lowercase, and digits';
        redirect(APP_URL . '/forgot_password.php');
    }

    if ($password !== $confirmPassword) {
        $_SESSION['error_msg'] = 'Passwords do not match';
        redirect(APP_URL . '/forgot_password.php');
    }

    // Get user by email
    $db = new Database();
    $stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");

    if (!$stmt) {
        $_SESSION['error_msg'] = 'Database error. Please try again later.';
        redirect(APP_URL . '/forgot_password.php');
    }

    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $_SESSION['error_msg'] = 'Email not found in our system';
        redirect(APP_URL . '/forgot_password.php');
    }

    $user = $result->fetch_assoc();
    $userId = $user['user_id'];

    // Hash new password
    $passwordHash = hashPassword($password);

    // Update password
    $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");

    if (!$stmt) {
        $_SESSION['error_msg'] = 'Database error. Please try again later.';
        redirect(APP_URL . '/forgot_password.php');
    }

    $stmt->bind_param('si', $passwordHash, $userId);

    if ($stmt->execute()) {
        // Clear session
        unset($_SESSION['reset_email']);
        
        $_SESSION['success_msg'] = 'Password has been reset successfully. Please login with your new password.';
        redirect(APP_URL . '/login.php');
    } else {
        $_SESSION['error_msg'] = 'Failed to reset password. Please try again.';
        redirect(APP_URL . '/forgot_password.php');
    }
}

else {
    $_SESSION['error_msg'] = 'Invalid request';
    redirect(APP_URL . '/forgot_password.php');
}

?>
