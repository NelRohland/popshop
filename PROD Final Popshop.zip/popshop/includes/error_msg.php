<?php
/**
 * Error and Success Messages Display
 * Shows flash messages stored in session
 */
?>

<?php if (isset($_SESSION['error_msg'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo sanitize($_SESSION['error_msg']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['error_msg']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['success_msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo sanitize($_SESSION['success_msg']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['success_msg']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['warning_msg'])): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <?php echo sanitize($_SESSION['warning_msg']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['warning_msg']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['info_msg'])): ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <?php echo sanitize($_SESSION['info_msg']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['info_msg']); ?>
<?php endif; ?>
