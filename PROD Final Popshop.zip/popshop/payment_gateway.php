<?php
require_once "includes/config.php";
require_once "includes/db_connect.php";
require_once "includes/functions.php";

if (!isLoggedIn()) {
    redirect('login.php');
}

if (!isset($_SESSION['pending_checkout']) || empty($_SESSION['cart'])) {
    redirect('checkout.php');
}

$pending = $_SESSION['pending_checkout'];
$cart = $_SESSION['cart'];
$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

$page_title = 'Payment Gateway';
include "includes/header.php";
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Simulated Payment Gateway</h4>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <strong>Simulated Environment:</strong> No real payment will be processed. This is a demonstration of where a payment gateway (like PayFast, Ozow, or Stripe) would be integrated.
                    </div>

                    <div class="mb-4">
                        <h5>Order Summary</h5>
                        <div class="d-flex justify-content-between">
                            <span>Total Amount:</span>
                            <span class="fw-bold"><?php echo formatCurrency($total); ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Payment Method:</span>
                            <span><?php echo htmlspecialchars($pending['payment_method']); ?></span>
                        </div>
                    </div>

                    <form action="complete_purchase_logic.php" method="POST">
                        <!-- Hidden fields to pass checkout data to final logic -->
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="delivery_address" value="<?php echo htmlspecialchars($pending['delivery_address']); ?>">
                        <input type="hidden" name="delivery_city" value="<?php echo htmlspecialchars($pending['delivery_city']); ?>">
                        <input type="hidden" name="delivery_province" value="<?php echo htmlspecialchars($pending['delivery_province']); ?>">
                        <input type="hidden" name="delivery_postal_code" value="<?php echo htmlspecialchars($pending['delivery_postal_code']); ?>">
                        <input type="hidden" name="payment_method" value="<?php echo htmlspecialchars($pending['payment_method']); ?>">
                        <input type="hidden" name="notes" value="<?php echo htmlspecialchars($pending['notes'] ?? ''); ?>">

                        <div class="mb-3">
                            <label class="form-label">Card Number (Simulated)</label>
                            <input type="text" class="form-control" placeholder="4242 4242 4242 4242" disabled>
                        </div>
                        <div class="row mb-3">
                            <div class="col">
                                <label class="form-label">Expiry Date</label>
                                <input type="text" class="form-control" placeholder="MM/YY" disabled>
                            </div>
                            <div class="col">
                                <label class="form-label">CVV</label>
                                <input type="text" class="form-control" placeholder="123" disabled>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success btn-lg w-100">
                            Confirm & Place Order
                        </button>
                    </form>
                    
                    <div class="mt-3 text-center">
                        <a href="checkout.php" class="text-muted">Cancel and go back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "includes/footer.php"; ?>