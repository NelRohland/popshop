<?php
// Redirect to manage_products.php
header('Location: ' . (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . str_replace('user_listings.php', 'manage_products.php', $_SERVER['REQUEST_URI']));
exit;
