<?php
/**
 * Complete Purchase Logic
 * Handles order checkout and completion
 */

require_once dirname(__FILE__) . '/includes/db_connect.php';
require_once dirname(__FILE__) . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('Invalid request method');
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_message'] = 'Security validation failed. Please try again.';
    redirect(APP_URL . '/checkout.php');
}

// Check if user is logged in
if (!isLoggedIn()) {
    redirect(APP_URL . '/login.php');
}

// Get buyer ID
$buyer_id = getUserId();

// Get form data
$delivery_address = sanitize($_POST['delivery_address'] ?? '');
$delivery_city = sanitize($_POST['delivery_city'] ?? '');
$delivery_province = sanitize($_POST['delivery_province'] ?? '');
$delivery_postal_code = sanitize($_POST['delivery_postal_code'] ?? '');
$payment_method = sanitize($_POST['payment_method'] ?? '');
$notes = sanitize($_POST['notes'] ?? '');

// Validation
$errors = [];

if (empty($delivery_address)) {
    $errors[] = 'Delivery address is required';
}

if (empty($delivery_city)) {
    $errors[] = 'City is required';
}

if (empty($delivery_province)) {
    $errors[] = 'Province is required';
}

if (empty($delivery_postal_code)) {
    $errors[] = 'Postal code is required';
}

if (empty($payment_method)) {
    $errors[] = 'Payment method is required';
}

if (!empty($errors)) {
    $_SESSION['error_message'] = implode('<br>', $errors);
    redirect(APP_URL . '/checkout.php');
}

// Get cart items from session (this would be implemented in Phase 3)
if (empty($_SESSION['cart']) || count($_SESSION['cart']) === 0) {
    $_SESSION['error_message'] = 'Your cart is empty';
    redirect(APP_URL . '/browse_products.php');
}

// Begin transaction
$db->getConnection()->begin_transaction();

try {
    $total_amount = 0;
    $orders_created = [];

    // Group items by seller
    $items_by_seller = [];
    foreach ($_SESSION['cart'] as $item) {
        $product_id = $item['product_id'];
        $quantity = $item['quantity'];

        // Get product and seller info
        $stmt = $db->prepare("SELECT seller_id, price FROM products WHERE product_id = ? AND status = 'active'");
        $stmt->bind_param('i', $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();

        if (!$product) {
            throw new Exception('Product not found or no longer available');
        }

        $seller_id = $product['seller_id'];
        $item_total = $product['price'] * $quantity;
        $total_amount += $item_total;

        if (!isset($items_by_seller[$seller_id])) {
            $items_by_seller[$seller_id] = [];
        }

        $items_by_seller[$seller_id][] = [
            'product_id' => $product_id,
            'quantity' => $quantity,
            'unit_price' => $product['price'],
            'subtotal' => $item_total
        ];
    }

    // Create orders for each seller
    foreach ($items_by_seller as $seller_id => $items) {
        $seller_total = array_sum(array_column($items, 'subtotal'));

        $stmt = $db->prepare("INSERT INTO orders (buyer_id, seller_id, total_amount, delivery_address, delivery_city, delivery_province, delivery_postal_code, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->bind_param('iidssssss', $buyer_id, $seller_id, $seller_total, $delivery_address, $delivery_city, $delivery_province, $delivery_postal_code, $payment_method, $notes);

        if (!$stmt->execute()) {
            throw new Exception('Failed to create order');
        }

        $order_id = $db->getLastInsertId();
        $orders_created[] = $order_id;

        // Add order items
        foreach ($items as $item) {
            $stmt = $db->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)");

            $stmt->bind_param('iiidd', $order_id, $item['product_id'], $item['quantity'], $item['unit_price'], $item['subtotal']);

            if (!$stmt->execute()) {
                throw new Exception('Failed to add order items');
            }

            // Update product quantity
            $stmt = $db->prepare("UPDATE products SET quantity_available = quantity_available - ? WHERE product_id = ?");
            $stmt->bind_param('ii', $item['quantity'], $item['product_id']);

            if (!$stmt->execute()) {
                throw new Exception('Failed to update product quantity');
            }
        }
    }

    // Commit transaction
    $db->getConnection()->commit();

    // Clear cart
    unset($_SESSION['cart']);

    $_SESSION['success_message'] = 'Order completed successfully! Order ID: ' . implode(', ', $orders_created);
    redirect(APP_URL . '/purchase_success.php?orders=' . implode(',', $orders_created));

} catch (Throwable $e) {
    // Rollback transaction
    $db->getConnection()->rollback();

    $_SESSION['error_message'] = 'Purchase failed: ' . $e->getMessage();
    redirect(APP_URL . '/checkout.php');
}

?>
