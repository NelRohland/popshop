<?php
$page_title = 'Inventory Management';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database
$db = new Database();
$mysqli = $db->getConnection();

// Redirect to login if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Check if user is a seller or admin
if (!hasRole('seller') && !hasRole('admin')) {
    $_SESSION['error_message'] = 'You do not have access to this page.';
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle inventory update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];
    
    // Verify product belongs to seller
    $verify_query = "SELECT product_id FROM products WHERE product_id = $product_id AND seller_id = $user_id";
    $verify = $mysqli->query($verify_query)->fetch_assoc();
    
    if ($verify && $quantity >= 0) {
        $update_query = "UPDATE products SET quantity_available = $quantity WHERE product_id = $product_id";
        if ($mysqli->query($update_query)) {
            $_SESSION['success_message'] = 'Inventory updated successfully!';
        }
    }
    header('Location: ' . APP_URL . '/seller_inventory.php');
    exit;
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$sort = isset($_GET['sort']) ? sanitize($_GET['sort']) : 'name';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

// Build query
$product_where = "p.seller_id = $user_id";
$count_where = "seller_id = $user_id";

if (!empty($status_filter)) {
    $product_where .= " AND p.status = '$status_filter'";
    $count_where .= " AND status = '$status_filter'";
}

if (!empty($search)) {
    $search_escaped = $mysqli->real_escape_string($search);
    $product_where .= " AND p.product_name LIKE '%$search_escaped%'";
    $count_where .= " AND product_name LIKE '%$search_escaped%'";
}

// Get total products
$count_query = "SELECT COUNT(*) as total FROM products WHERE $count_where";
$total_products = $mysqli->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_products / $per_page);

// Get products
$order_by = 'p.product_name ASC';
switch ($sort) {
    case 'stock_low':
        $order_by = 'p.quantity_available ASC';
        break;
    case 'stock_high':
        $order_by = 'p.quantity_available DESC';
        break;
    case 'price_low':
        $order_by = 'p.price ASC';
        break;
    case 'price_high':
        $order_by = 'p.price DESC';
        break;
    case 'recent':
        $order_by = 'p.created_at DESC';
        break;
}

$products_query = "
SELECT p.*,
       (SELECT COUNT(*) FROM product_images WHERE product_id = p.product_id) as image_count
FROM products p
WHERE $product_where
ORDER BY $order_by
LIMIT $offset, $per_page
";
$products = $mysqli->query($products_query)->fetch_all(MYSQLI_ASSOC);

// Get inventory statistics
$stats_query = "
SELECT 
    COUNT(*) as total_products,
    SUM(quantity_available) as total_stock,
    COUNT(CASE WHEN quantity_available = 0 THEN 1 END) as out_of_stock,
    COUNT(CASE WHEN quantity_available < 5 THEN 1 END) as low_stock,
    SUM(quantity_available * price) as stock_value
FROM products
WHERE $count_where
";
$stats = $mysqli->query($stats_query)->fetch_assoc();
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="section-title">Inventory Management</h1>
    </div>
</div>

<!-- Inventory Stats -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: var(--primary-color);">📦</div>
            <div class="stat-content">
                <p class="stat-label">Total Products</p>
                <h3 class="stat-value"><?php echo $stats['total_products']; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #27ae60;">📊</div>
            <div class="stat-content">
                <p class="stat-label">Total Stock</p>
                <h3 class="stat-value"><?php echo $stats['total_stock'] ?? 0; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #f39c12;">⚠️</div>
            <div class="stat-content">
                <p class="stat-label">Low Stock</p>
                <h3 class="stat-value"><?php echo $stats['low_stock']; ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon" style="background-color: #e74c3c;">❌</div>
            <div class="stat-content">
                <p class="stat-label">Out of Stock</p>
                <h3 class="stat-value"><?php echo $stats['out_of_stock']; ?></h3>
            </div>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="row mb-4">
    <div class="col-12">
        <div class="filter-card">
            <form method="GET" action="<?php echo APP_URL; ?>/seller_inventory.php" class="row g-3">
                <div class="col-md-5">
                    <input type="text" name="search" class="form-control" placeholder="Search products..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="sort" class="form-select">
                        <option value="name" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Name (A-Z)</option>
                        <option value="stock_low" <?php echo $sort === 'stock_low' ? 'selected' : ''; ?>>Stock (Low)</option>
                        <option value="stock_high" <?php echo $sort === 'stock_high' ? 'selected' : ''; ?>>Stock (High)</option>
                        <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price (Low)</option>
                        <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price (High)</option>
                        <option value="recent" <?php echo $sort === 'recent' ? 'selected' : ''; ?>>Recent</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (!empty($products)): ?>
<!-- Products Inventory Table -->
<div class="row">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Stock Value</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td>
                                <div class="product-info">
                                    <strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                                    <br>
                                    <small class="text-muted">ID: <?php echo $product['product_id']; ?></small>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($product['category']); ?></td>
                            <td><?php echo formatCurrency($product['price']); ?></td>
                            <td>
                                <span class="badge <?php echo $product['quantity_available'] === 0 ? 'bg-danger' : ($product['quantity_available'] < 5 ? 'bg-warning' : 'bg-success'); ?>">
                                    <?php echo $product['quantity_available']; ?> units
                                </span>
                            </td>
                            <td>
                                <?php echo formatCurrency($product['quantity_available'] * $product['price']); ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $product['status'] === 'active' ? 'bg-success' : 'bg-secondary'; ?>">
                                    <?php echo ucfirst($product['status']); ?>
                                </span>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" 
                                        data-bs-target="#inventoryModal<?php echo $product['product_id']; ?>">
                                    Edit
                                </button>
                            </td>
                        </tr>

                        <!-- Inventory Update Modal -->
                        <div class="modal fade" id="inventoryModal<?php echo $product['product_id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Update Stock - <?php echo htmlspecialchars(substr($product['product_name'], 0, 25)); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST">
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Current Stock</label>
                                                <p class="h4" style="color: var(--primary-color);">
                                                    <?php echo $product['quantity_available']; ?> units
                                                </p>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">New Stock Quantity</label>
                                                <input type="number" name="quantity" class="form-control" min="0" 
                                                       value="<?php echo $product['quantity_available']; ?>" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                                            <button type="submit" class="btn btn-primary">Update Stock</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo urlencode($sort); ?>&page=1">First</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo urlencode($sort); ?>&page=<?php echo $page - 1; ?>">Previous</a>
                    </li>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo urlencode($sort); ?>&page=<?php echo $i; ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo urlencode($sort); ?>&page=<?php echo $page + 1; ?>">Next</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo urlencode($sort); ?>&page=<?php echo $total_pages; ?>">Last</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php else: ?>
<div class="row">
    <div class="col-12">
        <div class="no-results">
            <div class="no-results-icon">📦</div>
            <h4>No Products Found</h4>
            <p class="no-results-text">No products match your filters.</p>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
.stat-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s, box-shadow 0.3s;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
}

.stat-content {
    flex: 1;
}

.stat-label {
    margin: 0;
    color: var(--text-muted);
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 600;
}

.stat-value {
    margin: 0.5rem 0 0 0;
    color: var(--dark-text);
    font-weight: 700;
    font-size: 1.75rem;
}

.filter-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.dashboard-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.product-info {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}
</style>

<?php require_once 'includes/footer.php'; ?>
