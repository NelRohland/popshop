<?php
/**
 * Add Product Logic
 * Handles product listing form submission
 */

require_once dirname(__FILE__) . '/includes/db_connect.php';
require_once dirname(__FILE__) . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('Invalid request method');
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    $_SESSION['error_msg'] = 'Security validation failed. Please try again.';
    redirect(APP_URL . '/add_product.php');
}

// Check if user is logged in and is seller
if (!isLoggedIn() || (!hasRole('seller') && !hasRole('admin'))) {
    $_SESSION['error_msg'] = 'You must be a seller to add products';
    redirect(APP_URL . '/index.php');
}

// Get form data
$seller_id = getUserId();
$product_name = sanitize($_POST['product_name'] ?? '');
$description = sanitize($_POST['description'] ?? '');
$category = sanitize($_POST['category'] ?? '');
$price = floatval($_POST['price'] ?? 0);
$quantity = intval($_POST['quantity'] ?? 0);
$condition = sanitize($_POST['condition'] ?? 'new');

// Validation
$errors = [];

if (empty($product_name)) {
    $errors[] = 'Product name is required';
} elseif (strlen($product_name) > 255) {
    $errors[] = 'Product name is too long';
}

if (empty($description)) {
    $errors[] = 'Description is required';
} elseif (strlen($description) < 20) {
    $errors[] = 'Description must be at least 20 characters';
}

if (empty($category)) {
    $errors[] = 'Category is required';
}

if ($price <= 0) {
    $errors[] = 'Price must be greater than 0';
}

if ($quantity <= 0) {
    $errors[] = 'Quantity must be greater than 0';
}

if (!in_array($condition, ['new', 'like_new', 'good', 'fair'])) {
    $errors[] = 'Invalid product condition';
}

// Handle file upload if provided
$main_image = null;
if (isset($_FILES['product_image']) && $_FILES['product_image']['size'] > 0) {
    $uploadResult = saveUploadedFile($_FILES['product_image']);
    if ($uploadResult['success']) {
        $main_image = $uploadResult['path'];
    } else {
        $errors[] = 'Image upload failed: ' . $uploadResult['message'];
    }
}

if (!empty($errors)) {
    $_SESSION['error_msg'] = implode('<br>', $errors);
    redirect(APP_URL . '/add_product.php');
}

// Insert product into database
$status = 'pending_approval'; // Admin approval required
$stmt = $db->prepare("INSERT INTO products (seller_id, product_name, description, category, price, quantity_available, condition, status, main_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    $_SESSION['error_msg'] = 'Database error. Please try again later.';
    redirect(APP_URL . '/add_product.php');
}

$stmt->bind_param('isssdisss', $seller_id, $product_name, $description, $category, $price, $quantity, $condition, $status, $main_image);

if ($stmt->execute()) {
    $_SESSION['success_msg'] = 'Product added successfully! It will appear after admin approval.';
    redirect(APP_URL . '/user_listings.php');
} else {
    $_SESSION['error_msg'] = 'Failed to add product. Please try again.';
    redirect(APP_URL . '/add_product.php');
}

?>
