<?php
$page_title = 'Register';
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect(APP_URL . '/index.php');
}

// Get form data from session if available (from previous failed submission)
$form_data = $_SESSION['form_data'] ?? [];
?>
<?php require_once 'includes/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body p-5">
                <h2 class="card-title text-center mb-4">Create Account</h2>

                <?php require_once 'includes/error_msg.php'; ?>

                <form method="POST" action="includes/register_logic.php" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">

                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" required 
                               value="<?php echo isset($form_data['full_name']) ? sanitize($form_data['full_name']) : ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required 
                               value="<?php echo isset($form_data['username']) ? sanitize($form_data['username']) : ''; ?>">
                        <small class="form-text text-muted">3-50 characters, no spaces</small>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required 
                               value="<?php echo isset($form_data['email']) ? sanitize($form_data['email']) : ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label for="user_type" class="form-label">Account Type</label>
                        <select class="form-select" id="user_type" name="user_type" required>
                            <option value="">Select an option</option>
                            <option value="buyer" <?php echo isset($form_data['user_type']) && $form_data['user_type'] === 'buyer' ? 'selected' : ''; ?>>Buyer</option>
                            <option value="seller" <?php echo isset($form_data['user_type']) && $form_data['user_type'] === 'seller' ? 'selected' : ''; ?>>Seller</option>
                        </select>
                        <small class="form-text text-muted">Choose whether you want to buy or sell products</small>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <small class="form-text text-muted">Min 8 chars, must include uppercase, lowercase, and digits</small>
                    </div>

                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mb-3">Create Account</button>
                </form>

                <hr>
                <p class="text-center">
                    Already have an account? <a href="login.php">Login here</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php 
// Clear form data from session after display
unset($_SESSION['form_data']);
require_once 'includes/footer.php'; 
?>
