<?php
$page_title = 'Browse Products';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database connection
$db = new Database();
$mysqli = $db->getConnection();

// Redirect to login if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Get search term and filters
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$selected_categories = isset($_GET['categories']) ? $_GET['categories'] : [];
$sort = isset($_GET['sort']) ? sanitize($_GET['sort']) : 'latest';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Build the query
$query = "SELECT p.*, 
          (SELECT COUNT(*) FROM product_images WHERE product_id = p.product_id) as image_count,
          u.username as seller_name
          FROM products p
          JOIN users u ON p.seller_id = u.user_id
          WHERE p.status = 'active'";

// Add search filter
if (!empty($search)) {
    $search_escaped = $mysqli->real_escape_string($search);
    $query .= " AND (p.product_name LIKE '%$search_escaped%' OR p.description LIKE '%$search_escaped%')";
}

// Add category filter
if (!empty($selected_categories)) {
    $categories_list = [];
    foreach ($selected_categories as $cat) {
        $categories_list[] = "'" . $mysqli->real_escape_string($cat) . "'";
    }
    $query .= " AND p.category IN (" . implode(',', $categories_list) . ")";
}

// Add sorting
switch ($sort) {
    case 'price_low':
        $query .= " ORDER BY p.price ASC";
        break;
    case 'price_high':
        $query .= " ORDER BY p.price DESC";
        break;
    case 'popular':
        $query .= " ORDER BY p.created_at DESC";
        break;
    default: // latest
        $query .= " ORDER BY p.created_at DESC";
}

// Get total count
$count_query = "SELECT COUNT(*) as total FROM products p WHERE p.status = 'active'";

if (!empty($search)) {
    $search_escaped = $mysqli->real_escape_string($search);
    $count_query .= " AND (p.product_name LIKE '%$search_escaped%' OR p.description LIKE '%$search_escaped%')";
}

if (!empty($selected_categories)) {
    $categories_list = [];
    foreach ($selected_categories as $cat) {
        $categories_list[] = "'" . $mysqli->real_escape_string($cat) . "'";
    }
    $count_query .= " AND p.category IN (" . implode(',', $categories_list) . ")";
}

$count_result = $mysqli->query($count_query);
$count_row = $count_result->fetch_assoc();
$total_products = $count_row['total'];
$total_pages = ceil($total_products / $per_page);

// Get products
$query .= " LIMIT $offset, $per_page";

$result = $mysqli->query($query);
$products = $result->fetch_all(MYSQLI_ASSOC);

// Get all categories for filter
$cat_query = "SELECT category_id, category_name FROM categories WHERE parent_category_id IS NULL ORDER BY category_name";
$cat_result = $mysqli->query($cat_query);
$categories = $cat_result->fetch_all(MYSQLI_ASSOC);
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-lg-8 offset-lg-2">
        <h1 class="section-title">Browse Marketplace</h1>
    </div>
</div>

<div class="row">
    <!-- Filters Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="filters-sidebar">
            <h5 class="filter-title">Filters</h5>
            
            <form method="GET" action="<?php echo APP_URL; ?>/browse_products.php" id="filterForm">
                <!-- Search -->
                <div class="filter-group">
                    <label class="filter-title">Search</label>
                    <input type="text" name="search" class="form-control search-input" 
                           placeholder="Product name..." value="<?php echo htmlspecialchars($search); ?>">
                </div>

                <!-- Categories -->
                <?php if (!empty($categories)): ?>
                <div class="filter-group">
                    <label class="filter-title">Category</label>
                    <?php foreach ($categories as $cat): ?>
                    <div class="filter-item">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="categories[]" 
                                   id="category_<?php echo $cat['category_id']; ?>" value="<?php echo htmlspecialchars($cat['category_name']); ?>"
                                   <?php echo in_array($cat['category_name'], $selected_categories) ? 'checked' : ''; ?>
                                   onchange="document.getElementById('filterForm').submit();">
                            <label class="form-check-label" for="category_<?php echo $cat['category_id']; ?>">
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </label>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Sort -->
                <div class="filter-group">
                    <label class="filter-title">Sort By</label>
                    <select name="sort" class="form-select" onchange="document.getElementById('filterForm').submit();">
                        <option value="latest" <?php echo $sort === 'latest' ? 'selected' : ''; ?>>Latest</option>
                        <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                        <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-outline-secondary w-100 mt-2">Clear Filters</a>
            </form>
        </div>
    </div>

    <!-- Products Grid -->
    <div class="col-lg-9">
        <!-- Search Results Info -->
        <div class="mb-4">
            <p class="text-muted">
                <?php 
                if (!empty($search)) {
                    echo "Showing results for \"" . htmlspecialchars($search) . "\" ";
                }
                echo "(" . $total_products . " product" . ($total_products !== 1 ? "s" : "") . " found)";
                ?>
            </p>
        </div>

        <?php if (!empty($products)): ?>
        <!-- Products Grid -->
        <div class="products-grid">
            <?php foreach ($products as $product): ?>
                <a href="product_details.php?id=<?php echo $product['product_id']; ?>" 
               class="product-card">
                <div class="product-card-image">
                    <?php if (!empty($product['main_image'])): ?>
                        <img src="<?php echo APP_URL; ?>/<?php echo htmlspecialchars($product['main_image']); ?>" 
                             alt="<?php echo htmlspecialchars($product['product_name']); ?>" 
                             class="product-image" 
                             onerror="this.src='<?php echo APP_URL; ?>/assets/placeholder.png'">
                    <?php else: ?>
                        <div class="product-image" style="background-color: #f0f0f0; display: flex; align-items: center; justify-content: center;">
                            <span style="color: #999;">No Image</span>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="product-card-body">
                    <p class="product-category"><?php echo htmlspecialchars($product['category']); ?></p>
                    <h5 class="product-title text-truncate-2">
                        <?php echo htmlspecialchars($product['product_name']); ?>
                    </h5>
                    <div class="mt-auto">
                        <p class="product-price mb-2"><?php echo formatCurrency($product['price']); ?></p>
                        <small class="text-muted d-block">
                            <?php echo ucfirst($product['condition']); ?> Condition
                        </small>
                        <small class="text-muted d-block">
                            Seller: <?php echo htmlspecialchars($product['seller_name']); ?>
                        </small>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <?php
        // Build query string with categories
        $query_params = 'search=' . urlencode($search) . '&sort=' . urlencode($sort);
        foreach ($selected_categories as $cat) {
            $query_params .= '&categories[]=' . urlencode($cat);
        }
        ?>
        <nav aria-label="Page navigation" class="mt-5">
            <ul class="pagination">
                <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?<?php echo $query_params; ?>&page=1">First</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="?<?php echo $query_params; ?>&page=<?php echo $page - 1; ?>">Previous</a>
                </li>
                <?php endif; ?>

                <?php
                $start_page = max(1, $page - 2);
                $end_page = min($total_pages, $page + 2);
                if ($start_page > 1): ?>
                <li class="page-item"><span class="page-link">...</span></li>
                <?php endif; ?>

                <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                    <a class="page-link" href="?<?php echo $query_params; ?>&page=<?php echo $i; ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>

                <?php if ($end_page < $total_pages): ?>
                <li class="page-item"><span class="page-link">...</span></li>
                <?php endif; ?>

                <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?<?php echo $query_params; ?>&page=<?php echo $page + 1; ?>">Next</a>
                </li>
                <li class="page-item">
                    <a class="page-link" href="?<?php echo $query_params; ?>&page=<?php echo $total_pages; ?>">Last</a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>

        <?php else: ?>
        <!-- No Results -->
        <div class="no-results">
            <div class="no-results-icon">✕</div>
            <h4>No Products Found</h4>
            <p class="no-results-text">
                <?php 
                if (!empty($search) || !empty($category) || !empty($condition)) {
                    echo "Try adjusting your search or filters to find more products.";
                } else {
                    echo "No products are currently available. Check back soon!";
                }
                ?>
            </p>
            <a href="<?php echo APP_URL; ?>/browse_products.php" class="btn btn-primary mt-3">Browse All Products</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>

