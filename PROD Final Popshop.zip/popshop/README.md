# PopShop Platform

Empowering informal traders and township entrepreneurs in South Africa with a safe and accessible digital marketplace.

## About PopShop

PopShop is a Customer-to-Customer (C2C) e-commerce platform designed for the South African market. It enables users to sign up as buyers or sellers, list products, make purchases, communicate via messaging, and complete secure digital transactions. The platform aims to minimize fraud, expand financial inclusion, and foster trust in online trade within underserved communities.

## Quick Start

### Installation

1. **Database Setup**
   ```bash
   # Import the database schema
   mysql -u root -p < docs/database_setup.sql
   ```

2. **Configuration**
   - Edit `includes/config.php` if needed
   - Database credentials: username=root, password=empty (default XAMPP)

3. **Access the Platform**
   - Navigate to: `http://localhost/popshop`

### First Time Setup

1. Register as a buyer or seller
2. Complete your profile
3. For sellers: Start listing products
4. For buyers: Browse and purchase products

## Project Phases

- **Phase 1**: Authentication (Current)
- **Phase 2**: Marketplace
- **Phase 3**: Buyer Features
- **Phase 4**: Seller Dashboard
- **Phase 5**: Admin Dashboard
- **Phase 6**: Responsive Design
- **Phase 7**: Deployment

## Current Features (Phase 1)

- User registration (buyer/seller)
- Secure login system
- Password hashing with bcrypt
- Session management
- CSRF protection
- Account status management

## Technology Stack

- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript
- **Backend**: PHP 7.4+
- **Database**: MySQL 8.0+
- **Server**: Apache (XAMPP)

## Documentation

- [Database Schema](docs/DB_SCHEMA.md) - Complete database structure
- [Development Guide](docs/DEVELOPMENT.md) - Development guidelines and best practices
- [Database Setup](docs/database_setup.sql) - SQL initialization script

## Key Features (Planned)

### For Buyers
- Browse product listings
- Product search and filtering
- Secure checkout
- Order tracking
- Direct messaging with sellers
- Fraud reporting

### For Sellers
- Product listing management
- Inventory tracking
- Order management
- Sales analytics
- Direct messaging with buyers
- Performance metrics

### For Admins
- User management
- Role-Based Access Control (RBAC)
- Fraud monitoring and investigation
- System reports
- Platform analytics
- Content moderation

## Security

- Secure password storage using bcrypt
- CSRF token protection
- SQL injection prevention (prepared statements)
- Input validation and sanitization
- Session-based authentication
- Role-based authorization

## Design Principles

- No unnecessary emojis or decorative elements
- Clean, professional interface
- Mobile-first responsive design
- Accessibility compliance
- Bootstrap-based consistent styling
- Fast loading times

## File Structure

```
popshop/
├── assets/           # CSS and JavaScript
├── includes/         # PHP includes and logic
├── uploads/          # Product images storage
├── docs/             # Documentation
└── [pages]           # Individual pages
```

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Support & Contributions

For development questions, refer to the [Development Guide](docs/DEVELOPMENT.md).

## License

This project is proprietary. All rights reserved.

---

**Platform**: PopShop C2C Marketplace  
**Location**: South Africa  
**Status**: In Development  
**Version**: 0.1 (Phase 1 - Authentication)
