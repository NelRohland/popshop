<?php
session_start();
require_once 'includes/functions.php';
require_once 'includes/reviews.php';

if (!isLoggedIn()) redirect('login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id'] ?? 0);
    $content = sanitize($_POST['content'] ?? '');
    $buyer_id = getUserId();

    if ($product_id && strlen($content) >= 10) {
        submitProductReview($product_id, $buyer_id, $content);
        $_SESSION['success_message'] = 'Review submitted for moderation.';
    } else {
        $_SESSION['error_message'] = 'Invalid review.';
    }
}

redirect($_SERVER['HTTP_REFERER'] ?? 'index.php');
