<?php
$page_title = 'Sales Analytics';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database
$db = new Database();
$mysqli = $db->getConnection();

// Redirect to login if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Check if user is a seller or admin
if (!hasRole('seller') && !hasRole('admin')) {
    $_SESSION['error_message'] = 'You do not have access to this page.';
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get date range from request
$period = isset($_GET['period']) ? sanitize($_GET['period']) : '30days';
$date_filter = '';

switch ($period) {
    case '7days':
        $date_filter = "DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        $label = 'Last 7 Days';
        break;
    case '90days':
        $date_filter = "DATE_SUB(CURDATE(), INTERVAL 90 DAY)";
        $label = 'Last 90 Days';
        break;
    case 'year':
        $date_filter = "DATE_SUB(CURDATE(), INTERVAL 1 YEAR)";
        $label = 'Last Year';
        break;
    case '30days':
    default:
        $date_filter = "DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
        $label = 'Last 30 Days';
}

// Get overall statistics
$stats_query = "
SELECT 
    COUNT(*) as total_orders,
    COUNT(CASE WHEN status IN ('paid', 'shipped', 'delivered') THEN 1 END) as completed_orders,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_order_value,
    SUM(CASE WHEN status IN ('paid', 'shipped', 'delivered') THEN total_amount ELSE 0 END) as completed_revenue
FROM orders
WHERE seller_id = $user_id AND DATE(order_date) >= $date_filter
";
$stats = $mysqli->query($stats_query)->fetch_assoc();

// Get daily sales
$daily_query = "
SELECT 
    DATE(order_date) as date,
    COUNT(*) as orders,
    SUM(total_amount) as revenue
FROM orders
WHERE seller_id = $user_id AND status IN ('paid', 'shipped', 'delivered') AND DATE(order_date) >= $date_filter
GROUP BY DATE(order_date)
ORDER BY DATE(order_date) DESC
";
$daily_sales = $mysqli->query($daily_query)->fetch_all(MYSQLI_ASSOC);

// Get top products
$top_products_query = "
SELECT 
    p.product_id,
    p.product_name,
    COUNT(oi.order_item_id) as quantity_sold,
    SUM(oi.quantity * oi.unit_price) as revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.seller_id = $user_id AND o.status IN ('paid', 'shipped', 'delivered') 
  AND DATE(o.order_date) >= $date_filter
GROUP BY p.product_id
ORDER BY revenue DESC
LIMIT 10
";
$top_products = $mysqli->query($top_products_query)->fetch_all(MYSQLI_ASSOC);

// Get category performance
$category_query = "
SELECT 
    p.category,
    COUNT(oi.order_item_id) as quantity_sold,
    COUNT(DISTINCT o.order_id) as orders,
    SUM(oi.quantity * oi.unit_price) as revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders o ON oi.order_id = o.order_id
WHERE o.seller_id = $user_id AND o.status IN ('paid', 'shipped', 'delivered')
  AND DATE(o.order_date) >= $date_filter
GROUP BY p.category
ORDER BY revenue DESC
LIMIT 5
";
$categories = $mysqli->query($category_query)->fetch_all(MYSQLI_ASSOC);

// Get order status distribution
$status_query = "
SELECT 
    status,
    COUNT(*) as count,
    SUM(total_amount) as revenue
FROM orders
WHERE seller_id = $user_id AND DATE(order_date) >= $date_filter
GROUP BY status
";
$statuses = $mysqli->query($status_query)->fetch_all(MYSQLI_ASSOC);
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1 class="section-title">Sales Analytics</h1>
    </div>
    <div class="col-md-4">
        <form method="GET" class="d-flex gap-2">
            <select name="period" class="form-select" onchange="this.form.submit();">
                <option value="7days" <?php echo $period === '7days' ? 'selected' : ''; ?>>Last 7 Days</option>
                <option value="30days" <?php echo $period === '30days' ? 'selected' : ''; ?>>Last 30 Days</option>
                <option value="90days" <?php echo $period === '90days' ? 'selected' : ''; ?>>Last 90 Days</option>
                <option value="year" <?php echo $period === 'year' ? 'selected' : ''; ?>>Last Year</option>
            </select>
        </form>
    </div>
</div>

<!-- Key Metrics -->
<div class="row mb-4">
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="metric-card">
            <p class="metric-label">Total Revenue</p>
            <h3 class="metric-value"><?php echo formatCurrency($stats['total_revenue'] ?? 0); ?></h3>
            <small class="metric-subtext"><?php echo $label; ?></small>
        </div>
    </div>
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="metric-card">
            <p class="metric-label">Orders Placed</p>
            <h3 class="metric-value"><?php echo $stats['total_orders']; ?></h3>
            <small class="metric-subtext"><?php echo $stats['completed_orders']; ?> completed</small>
        </div>
    </div>
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="metric-card">
            <p class="metric-label">Avg Order Value</p>
            <h3 class="metric-value"><?php echo formatCurrency($stats['avg_order_value'] ?? 0); ?></h3>
            <small class="metric-subtext">per order</small>
        </div>
    </div>
    <div class="col-md-6 col-lg-3 mb-3">
        <div class="metric-card">
            <p class="metric-label">Completed Revenue</p>
            <h3 class="metric-value"><?php echo formatCurrency($stats['completed_revenue'] ?? 0); ?></h3>
            <small class="metric-subtext">from completed orders</small>
        </div>
    </div>
</div>

<div class="row mb-4">
    <!-- Daily Sales Chart -->
    <div class="col-lg-8">
        <div class="analytics-card">
            <h5 class="card-title">Daily Sales</h5>
            <?php if (!empty($daily_sales)): ?>
            <div class="daily-chart">
                <?php 
                $max_revenue = max(array_column($daily_sales, 'revenue'));
                foreach (array_reverse($daily_sales) as $day):
                ?>
                <div class="daily-item">
                    <div class="daily-bar" style="height: <?php echo ($day['revenue'] / $max_revenue) * 150 ?>px; background-color: var(--primary-color);" 
                         title="$<?php echo number_format($day['revenue'], 2); ?>">
                    </div>
                    <small class="daily-label"><?php echo date('M d', strtotime($day['date'])); ?></small>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="text-muted">No sales data for this period</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Order Status Distribution -->
    <div class="col-lg-4">
        <div class="analytics-card">
            <h5 class="card-title">Order Status</h5>
            <?php if (!empty($statuses)): ?>
            <div class="status-list">
                <?php foreach ($statuses as $s): ?>
                <div class="status-item">
                    <span class="status-name"><?php echo ucfirst($s['status']); ?></span>
                    <div class="status-bar-container">
                        <div class="status-bar" style="width: <?php 
                            $total = array_sum(array_column($statuses, 'count'));
                            echo ($s['count'] / $total) * 100;
                        ?>%; background-color: <?php
                            $colors = [
                                'pending' => '#f39c12',
                                'paid' => '#27ae60',
                                'shipped' => '#3498db',
                                'delivered' => '#27ae60',
                                'cancelled' => '#e74c3c',
                                'refunded' => '#95a5a6'
                            ];
                            echo $colors[$s['status']] ?? '#7f8c8d';
                        ?>;"></div>
                    </div>
                    <span class="status-count"><?php echo $s['count']; ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="text-muted">No order data</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row mb-4">
    <!-- Top Products -->
    <div class="col-lg-6">
        <div class="analytics-card">
            <h5 class="card-title">Top Products</h5>
            <?php if (!empty($top_products)): ?>
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Sold</th>
                            <th>Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($top_products as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars(substr($product['product_name'], 0, 25)); ?></td>
                            <td><?php echo $product['quantity_sold']; ?></td>
                            <td><strong><?php echo formatCurrency($product['revenue']); ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-muted">No sales data</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Category Performance -->
    <div class="col-lg-6">
        <div class="analytics-card">
            <h5 class="card-title">Category Performance</h5>
            <?php if (!empty($categories)): ?>
            <div class="category-list">
                <?php foreach ($categories as $cat): ?>
                <div class="category-item">
                    <div class="category-info">
                        <span class="category-name"><?php echo htmlspecialchars($cat['category']); ?></span>
                        <span class="category-stats"><?php echo $cat['quantity_sold']; ?> sold | <?php echo $cat['orders']; ?> orders</span>
                    </div>
                    <span class="category-revenue"><?php echo formatCurrency($cat['revenue']); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="text-muted">No sales data</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.metric-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s;
}

.metric-card:hover {
    transform: translateY(-2px);
}

.metric-label {
    margin: 0;
    color: var(--text-muted);
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.metric-value {
    margin: 0.5rem 0 0 0;
    color: var(--dark-text);
    font-weight: 700;
    font-size: 1.75rem;
}

.metric-subtext {
    color: var(--text-muted);
}

.analytics-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.card-title {
    margin: 0 0 1.5rem 0;
    color: var(--dark-text);
    font-weight: 600;
}

.daily-chart {
    display: flex;
    align-items: flex-end;
    justify-content: space-around;
    height: 200px;
    gap: 0.5rem;
}

.daily-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
    flex: 1;
}

.daily-bar {
    width: 100%;
    min-width: 20px;
    border-radius: 4px 4px 0 0;
    transition: background-color 0.3s;
}

.daily-bar:hover {
    background-color: var(--primary-dark) !important;
}

.daily-label {
    font-size: 0.75rem;
    color: var(--text-muted);
}

.status-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.status-item {
    display: grid;
    grid-template-columns: 80px 1fr 40px;
    gap: 0.75rem;
    align-items: center;
}

.status-name {
    font-weight: 500;
    color: var(--dark-text);
    font-size: 0.9rem;
}

.status-bar-container {
    background-color: var(--border-light);
    height: 8px;
    border-radius: 4px;
    overflow: hidden;
}

.status-bar {
    height: 100%;
    border-radius: 4px;
}

.status-count {
    font-weight: 600;
    color: var(--dark-text);
    font-size: 0.9rem;
    text-align: right;
}

.category-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.category-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background-color: var(--light-bg);
    border-radius: 6px;
}

.category-info {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.category-name {
    font-weight: 600;
    color: var(--dark-text);
}

.category-stats {
    font-size: 0.85rem;
    color: var(--text-muted);
}

.category-revenue {
    font-weight: 700;
    color: var(--primary-color);
}
</style>

<?php require_once 'includes/footer.php'; ?>
