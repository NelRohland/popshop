<?php
$page_title = 'Manage Orders';
require_once 'includes/config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Initialize database
$db = new Database();
$mysqli = $db->getConnection();

// Redirect to login if not logged in
if (!isLoggedIn()) {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

// Check if user is a seller or admin
if (!hasRole('seller') && !hasRole('admin')) {
    $_SESSION['error_message'] = 'You do not have access to this page.';
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $order_id = (int)$_POST['order_id'];
    $new_status = sanitize($_POST['new_status']);
    
    // Verify order belongs to seller
    $verify_query = "SELECT order_id FROM orders WHERE order_id = $order_id AND seller_id = $user_id";
    $verify = $mysqli->query($verify_query)->fetch_assoc();
    
    if ($verify) {
        $update_query = "UPDATE orders SET status = '$new_status' WHERE order_id = $order_id";
        if ($mysqli->query($update_query)) {
            $_SESSION['success_message'] = 'Order status updated successfully!';
        }
    }
    header('Location: ' . APP_URL . '/seller_orders.php');
    exit;
}

// Get filter and search parameters
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Build query
$where = "o.seller_id = $user_id";

if (!empty($status_filter)) {
    $where .= " AND o.status = '$status_filter'";
}

if (!empty($search)) {
    $search_escaped = $mysqli->real_escape_string($search);
    $where .= " AND (u.username LIKE '%$search_escaped%' OR o.order_id LIKE '%$search_escaped%')";
}

// Get total orders
$count_query = "SELECT COUNT(*) as total FROM orders o 
                JOIN users u ON o.buyer_id = u.user_id 
                WHERE $where";
$total_orders = $mysqli->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_orders / $per_page);

// Get orders with items
$orders_query = "
SELECT o.*, 
       u.username as buyer_name, u.email as buyer_email,
       COUNT(oi.order_item_id) as item_count,
       SUM(oi.quantity) as total_qty
FROM orders o
JOIN users u ON o.buyer_id = u.user_id
LEFT JOIN order_items oi ON o.order_id = oi.order_id
WHERE $where
GROUP BY o.order_id
ORDER BY o.order_date DESC
LIMIT $offset, $per_page
";
$orders = $mysqli->query($orders_query)->fetch_all(MYSQLI_ASSOC);

$statuses = ['pending', 'paid', 'shipped', 'delivered', 'cancelled', 'refunded'];
?>
<?php require_once 'includes/header.php'; ?>

<div class="row mb-4">
    <div class="col-12">
        <h1 class="section-title">Manage Orders</h1>
    </div>
</div>

<!-- Filters -->
<div class="row mb-4">
    <div class="col-12">
        <div class="filter-card">
            <form method="GET" action="<?php echo APP_URL; ?>/seller_orders.php" class="row g-3">
                <div class="col-md-6">
                    <input type="text" name="search" class="form-control" placeholder="Search by order ID or buyer name..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">All Statuses</option>
                        <?php foreach ($statuses as $s): ?>
                        <option value="<?php echo $s; ?>" <?php echo $status_filter === $s ? 'selected' : ''; ?>>
                            <?php echo ucfirst($s); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (!empty($orders)): ?>
<!-- Orders Table -->
<div class="row">
    <div class="col-12">
        <div class="dashboard-card">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Buyer</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Order Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <strong>#<?php echo $order['order_id']; ?></strong>
                            </td>
                            <td>
                                <div>
                                    <strong><?php echo htmlspecialchars($order['buyer_name']); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo htmlspecialchars($order['buyer_email']); ?></small>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?php echo $order['item_count']; ?> items</span>
                            </td>
                            <td>
                                <strong><?php echo formatCurrency($order['total_amount']); ?></strong>
                            </td>
                            <td>
                                <span class="badge" style="background-color: <?php 
                                    $status_color = [
                                        'pending' => '#f39c12',
                                        'paid' => '#27ae60',
                                        'shipped' => '#3498db',
                                        'delivered' => '#27ae60',
                                        'cancelled' => '#e74c3c',
                                        'refunded' => '#95a5a6'
                                    ];
                                    echo $status_color[$order['status']] ?? '#7f8c8d';
                                ?>;">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <small><?php echo date('M d, Y', strtotime($order['order_date'])); ?></small>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" 
                                        data-bs-target="#orderModal<?php echo $order['order_id']; ?>">
                                    View
                                </button>
                            </td>
                        </tr>

                        <!-- Order Detail Modal -->
                        <div class="modal fade" id="orderModal<?php echo $order['order_id']; ?>" tabindex="-1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Order #<?php echo $order['order_id']; ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <h6>Buyer Information</h6>
                                                <p>
                                                    <strong><?php echo htmlspecialchars($order['buyer_name']); ?></strong><br>
                                                    <?php echo htmlspecialchars($order['buyer_email']); ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6>Delivery Address</h6>
                                                <p>
                                                    <?php echo htmlspecialchars($order['delivery_address']); ?><br>
                                                    <?php echo htmlspecialchars($order['delivery_city']); ?>, <?php echo htmlspecialchars($order['delivery_province']); ?> <?php echo htmlspecialchars($order['delivery_postal_code']); ?>
                                                </p>
                                            </div>
                                        </div>

                                        <hr>

                                        <h6>Order Items</h6>
                                        <?php 
                                        $items_query = "
                                        SELECT oi.*, p.product_name
                                        FROM order_items oi
                                        JOIN products p ON oi.product_id = p.product_id
                                        WHERE oi.order_id = {$order['order_id']}
                                        ";
                                        $items = $mysqli->query($items_query)->fetch_all(MYSQLI_ASSOC);
                                        ?>
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Qty</th>
                                                    <th>Price</th>
                                                    <th>Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($items as $item): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                                    <td><?php echo $item['quantity']; ?></td>
                                                    <td><?php echo formatCurrency($item['unit_price']); ?></td>
                                                    <td><strong><?php echo formatCurrency($item['quantity'] * $item['unit_price']); ?></strong></td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>

                                        <hr>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6>Order Total</h6>
                                                <p class="h5" style="color: var(--primary-color);">
                                                    <?php echo formatCurrency($order['total_amount']); ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6">
                                                <h6>Update Status</h6>
                                                <form method="POST" class="d-flex gap-2">
                                                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                    <select name="new_status" class="form-select form-select-sm">
                                                        <?php foreach ($statuses as $s): ?>
                                                        <option value="<?php echo $s; ?>" 
                                                                <?php echo $order['status'] === $s ? 'selected' : ''; ?>>
                                                            <?php echo ucfirst($s); ?>
                                                        </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                    <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                                </form>
                                            </div>
                                        </div>

                                        <?php if (!empty($order['notes'])): ?>
                                        <hr>
                                        <h6>Notes</h6>
                                        <p><?php echo htmlspecialchars($order['notes']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&page=1">First</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page - 1; ?>">Previous</a>
                    </li>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $i; ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page + 1; ?>">Next</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $total_pages; ?>">Last</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php else: ?>
<div class="row">
    <div class="col-12">
        <div class="no-results">
            <div class="no-results-icon">📦</div>
            <h4>No Orders Found</h4>
            <p class="no-results-text">No orders match your filters.</p>
            <a href="<?php echo APP_URL; ?>/seller_orders.php" class="btn btn-primary mt-3">Clear Filters</a>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
.filter-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.dashboard-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}
</style>

<?php require_once 'includes/footer.php'; ?>
